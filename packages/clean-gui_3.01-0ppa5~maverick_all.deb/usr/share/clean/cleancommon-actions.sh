#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## 16/12/2011
## Special thanks to Babdu89, Josepe36, and GRUB devs.

## LIBRAIRIES FOR OS-UNINSTALLER AND BOOT REPAIR
## http://ubuntuforums.org/showthread.php?t=1615667


################################### RESTORE MBR ###########################################
restore_mbr()
{
DISK_TO_RESTORE_MBR="${MBR_TO_RESTORE%% (*}"
echo "We will restore the MBR_TO_RESTORE : $MBR_TO_RESTORE into $DISK_TO_RESTORE_MBR"
#mkdir -p $TMP_FOLDER/$DISK_TO_RESTORE_MBR/
#for ((i=1;i<=NBOFDISKS;i++)); do
#  if [[ "${LISTOFDISKS[$i]}" = "$DISK_TO_RESTORE_MBR" ]];then NUMERO_DISK_TO_RESTORE_MBR="$i";fi #Because BYTES_BEFORE_PART[@Num_disk]
#done
temp="${MBR_TO_RESTORE#* (}"; BETWEEN_PARENTHESIS="${temp%)*}"
echo "SET@_label0.set_text('''$Restore_MBR. $(eval_gettext $'Please wait few seconds...')''')"
if [[ -f $TMP_FOLDER/$DISK_TO_RESTORE_MBR/current_mbr.img ]];then	#Security
	cp $TMP_FOLDER/$DISK_TO_RESTORE_MBR/current_mbr.img $TMP_FOLDER/$DISK_TO_RESTORE_MBR/mbr_before_restoring_mbr.img
	if [[ "$(grep "generic" <<< $MBR_TO_RESTORE )" ]];then
		if [[ -f /sbin/install-mbr ]];then
			install-mbr -e ${TARGET_PARTITION_FOR_MBR} /dev/${DISK_TO_RESTORE_MBR}; echo "install-mbr -e ${TARGET_PARTITION_FOR_MBR} /dev/${DISK_TO_RESTORE_MBR}"
		else
			echo "Error : /sbin/install-mbr not found."; zenity --error --text="Error : please install the [mbr] package and retry."
		fi
	elif [[ "$(grep "mbr" <<< $BETWEEN_PARENTHESIS )" ]] && [[ -f /usr/lib/syslinux/${BETWEEN_PARENTHESIS}.bin ]];then
		echo "dd if=/usr/lib/syslinux/${BETWEEN_PARENTHESIS}.bin of=/dev/${DISK_TO_RESTORE_MBR}"
		dd if=/usr/lib/syslinux/${BETWEEN_PARENTHESIS}.bin of=/dev/${DISK_TO_RESTORE_MBR} bs=446 count=1
		echo "parted /dev/${DISK_TO_RESTORE_MBR} set ${TARGET_PARTITION_FOR_MBR} boot on"
		parted /dev/${DISK_TO_RESTORE_MBR} set ${TARGET_PARTITION_FOR_MBR} boot on
	elif [[ $(ls "$TMP_FOLDER/${DISK_TO_RESTORE_MBR}/" | grep "mbr-$(cut -c-10 <<< "$BETWEEN_PARENTHESIS" )__$(cut -c12-13 <<< "$BETWEEN_PARENTHESIS" )h$(cut -c15-16 <<< "$BETWEEN_PARENTHESIS" )" ) ]]; then
		restore_mbr_backup_into_the_mbr $(ls "$TMP_FOLDER/${DISK_TO_RESTORE_MBR}/" | grep "mbr-$(cut -c-10 <<< "$BETWEEN_PARENTHESIS" )__$(cut -c12-13 <<< "$BETWEEN_PARENTHESIS" )h$(cut -c15-16 <<< "$BETWEEN_PARENTHESIS" )" ) ${DISK_TO_RESTORE_MBR}
	elif [[ $(ls "$TMP_FOLDER/${DISK_TO_RESTORE_MBR}/" | grep "mbr-$(cut -c-10 <<< "$BETWEEN_PARENTHESIS" )__$(cut -c12-13 <<< "$BETWEEN_PARENTHESIS" ):$(cut -c15-16 <<< "$BETWEEN_PARENTHESIS" )" ) ]]; then
		restore_mbr_backup_into_the_mbr $(ls "$TMP_FOLDER/${DISK_TO_RESTORE_MBR}/" | grep "mbr-$(cut -c-10 <<< "$BETWEEN_PARENTHESIS" )__$(cut -c12-13 <<< "$BETWEEN_PARENTHESIS" ):$(cut -c15-16 <<< "$BETWEEN_PARENTHESIS" )" ) ${DISK_TO_RESTORE_MBR}
	else
		echo "Error : $MBR_TO_RESTORE [$BETWEEN_PARENTHESIS] could not be restored in $DISK_TO_RESTORE_MBR."
		ls "$TMP_FOLDER/${DISK_TO_RESTORE_MBR}/"	#debug
		zenity --error --text="Error : $MBR_TO_RESTORE could not be restored in $DISK_TO_RESTORE_MBR."
	fi
else
	echo "Error : $TMP_FOLDER/$DISK_TO_RESTORE_MBR/current_mbr.img does not exist"
	zenity --error --text="Error : $TMP_FOLDER/$DISK_TO_RESTORE_MBR/current_mbr.img does not exist. MBR could not be restored."
fi
}

# called by : restore_mbr
restore_mbr_backup_into_the_mbr()
{
if [[ -f "$TMP_FOLDER/$2/$1" ]];then	#Security
	echo "Restore the Clean-Ubiquity MBR backup $1 into the MBR of disk $2"
	mv "$TMP_FOLDER/$2/current_mbr.img" "$TMP_FOLDER/$2/mbr_before_restoration.img"
	dd if="$TMP_FOLDER/$2/$1" of=/dev/$2 bs=446 count=1 #Stops before the partition table
else 
	echo "Error : $TMP_FOLDER/$2/$1 does not exist"
	zenity --error --text="Error : MBR backup $TMP_FOLDER/$2/$1 does not exist. MBR could not be restored."
fi
}


################################ REINSTALL GRUB ##################################################
reinstall_action()
{
if [[ "$FORCE_GRUB" = "all" ]];then
	if [[ "$REMOVABLEDISK" = "yes" ]];then
		echo "REMOVABLEDISK is Yes, so we reinstall GRUB of the removable media only in its disk MBR"
		NOFORCE_DISK="${DISK_PART[$PART_TO_REINSTALL_GRUB]}"; reinstall_grub
		REMOVABLE_PART_TO_REINSTALL_GRUB="$PART_TO_REINSTALL_GRUB"
		PART_TO_REINSTALL_GRUB="none"
		for ((x=1;x<=QTY_OF_PART_WITH_GRUB;x++)); do
			if [[ "${DISK_PART[$REMOVABLE_PART_TO_REINSTALL_GRUB]}" != "${DISK_PART[${LIST_OF_PART_WITH_GRUB[$x]}]}" ]] && [[ "$PART_TO_REINSTALL_GRUB" = "none" ]] && [[ "${LISTOFPARTITIONS[${LIST_OF_PART_WITH_GRUB[$x]}]}" != "$OS_TO_DELETE_PARTITION" ]]; then
				PART_TO_REINSTALL_GRUB="${LIST_OF_PART_WITH_GRUB[$x]}"
				loop_install_grub_in_all_other_disks
			fi
		done
	else
		REMOVABLE_PART_TO_REINSTALL_GRUB=""
		loop_install_grub_in_all_other_disks
	fi
else
	reinstall_grub
fi
}

loop_install_grub_in_all_other_disks()
{
echo "Reinstall the GRUB of ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]} into all MBRs of disks with OS or not-USB"
for ((n=1;n<=NBOFDISKS;n++)); do
#	a=$(sudo parted -l /dev/${LISTOFDISKS[$n]} | grep ${LISTOFDISKS[$n]})
#	b=${a#*: }
#	DISKSIZE=${b%,*}
#	if [[ "$DISKSIZE" > "20" ]] 
	if [[ ! "$(ls -l /dev/disk/by-id | grep " usb-" | grep "${LISTOFDISKS[$n]}")" ]] || [[ "${DISK_WITHOS[$n]}" = "with-os" ]] && [[ "${LISTOFDISKS[$n]}" != "${DISK_PART[$REMOVABLE_PART_TO_REINSTALL_GRUB]}" ]];then
		NOFORCE_DISK="${LISTOFDISKS[$n]}"; reinstall_grub
	fi
done
}

reinstall_grub()
{
if [[ "$FORCE_GRUB" = "yes" ]]; then 
	GRUBSTAGEONE="$FORCE_PARTITION"; echo "Reinstall the GRUB of ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]} into the $GRUBSTAGEONE partition"
	reinstall_grubstageone
else
	GRUBSTAGEONE="$NOFORCE_DISK"; echo "Reinstall the GRUB of ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]} into the MBR of $GRUBSTAGEONE"
	if [[ -f $TMP_FOLDER/$GRUBSTAGEONE/current_mbr.img ]];then	#Security
		reinstall_grubstageone
	else
		echo "Error : $TMP_FOLDER/$GRUBSTAGEONE/current_mbr.img does not exist"
		zenity --error --text="Error : $TMP_FOLDER/$GRUBSTAGEONE/current_mbr.img does not exist. GRUB could not be reinstalled."
	fi
fi
}

reinstall_grubstageone()
{
force_unmount_os_partitions_in_mnt_except_reinstall_grub	#OS are not recognized if partitions are not unmounted
if [[ "$BLANKEXTRA_ACTION" = "yes" ]];then
	blankextraspace
fi
if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then #Current session
	dpkg_function
	echo "SET@_label0.set_text('''$Reinstall_GRUB $GRUBSTAGEONE. $(eval_gettext $'This may require several minutes...')''')"
	grub-install -v #Debug
	if [[ "$ATA" = "ata" ]];then
		grub-install --recheck --disk-module=ata /dev/$GRUBSTAGEONE
	else
		grub-install --recheck /dev/$GRUBSTAGEONE
	fi
	if [[ "$UNCOMMENT_GFXMODE" = "yes" ]];then
		uncomment_gfxmode
	fi
	if [[ "$ADD_KERNEL_OPTION" = "yes" ]];then
		add_kernel_option
	fi
	echo "SET@_label0.set_text('''Update GRUB. $(eval_gettext $'This may require several minutes...')''')"
	update-grub
else
	prepare_chroot
	dpkg_function
	echo "SET@_label0.set_text('''$Reinstall_GRUB $GRUBSTAGEONE. $(eval_gettext $'This may require several minutes...')''')"
	chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" grub-install -v #Debug
	if [[ "$ATA" = "ata" ]];then
		chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" grub-install --recheck --disk-module=ata /dev/$GRUBSTAGEONE
	else
		chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" grub-install --recheck /dev/$GRUBSTAGEONE
	fi
	if [[ "$UNCOMMENT_GFXMODE" = "yes" ]];then
		uncomment_gfxmode
	fi
	if [[ "$ADD_KERNEL_OPTION" = "yes" ]];then
		add_kernel_option
	fi
	echo "SET@_label0.set_text('''Update GRUB. $(eval_gettext $'This may require several minutes...')''')"
	chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" update-grub
	unchroot_linux_to_reinstall
fi
mount_all_blkid_partitions_except_df ; echo "Mount all the partitions for the logs"
}

blankextraspace()
{
rm -f /tmp/clean_sort
for partition in $(ls "/sys/block/$GRUBSTAGEONE/" | grep "$GRUBSTAGEONE");do
	echo "$(cat "/sys/block/$GRUBSTAGEONE/${partition}/start" )" >> /tmp/clean_sort
done
echo "63" >> /tmp/clean_sort # Blank maximum 62 sectors (in case the first partition is far)
a=$(cat "/tmp/clean_sort" | sort -g -r | tail -1 )  #sort the file in the increasing order
if [[ "$(grep "^[0-9]\+$" <<< $a )" ]];then
	SECTORS_TO_WIPE=$(($a-1))
else
	SECTORS_TO_WIPE="-1"
fi
rm /tmp/clean_sort
#  a=$(LANGUAGE=C LC_ALL=C fdisk -lu /dev/$disk | grep "sectors of"); b=${a##*= }; c=${b% *}; echo "$c" > /tmp/clean_sort   #Other way to calculate
BYTES_PER_SECTOR="$(stat -c %B /dev/$GRUBSTAGEONE)"
echo "WIPE $GRUBSTAGEONE : ${SECTORS_BEFORE_PART} sectors * ${BYTES_PER_SECTOR} bytes"
if [[ "$SECTORS_TO_WIPE" -gt "0" ]] && [[ "$SECTORS_TO_WIPE" -le "62" ]] && [[ "$BYTES_PER_SECTOR" -ge "512" ]] && [[ "$BYTES_PER_SECTOR" -le "1024" ]];then
	end_of_pulsate
	zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="This will erase $SECTORS_TO_WIPE sectors following the 1st sector of $GRUBSTAGEONE. One sector is $BYTES_PER_SECTOR bytes. ${Do_you_want_to_continue}" || wipeok="no"
	beginning_of_pulsate
	if [[ "$wipeok" != "no" ]];then
		dd if=/dev/zero of=/dev/$GRUBSTAGEONE bs=$BYTES_PER_SECTOR count=$SECTORS_TO_WIPE seek=1
	fi
else
	end_of_pulsate
	zenity --warning --title="$(eval_gettext "$CLEANNAME")" --text="By security, $GRUBSTAGEONE sectors were not wiped. (one of these values is incorrect: SECTORS_TO_WIPE=$SECTORS_TO_WIPE , BYTES_PER_SECTOR=$BYTES_PER_SECTOR )"
	beginning_of_pulsate
fi
}

#####Used by repair, uninstaller (for GRUB reinstall, and purge)
force_unmount_os_partitions_in_mnt_except_reinstall_grub()
{
echo "Unmount (force) all OS partitions except / and partition where we reinstall GRUB (${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]})"
echo "SET@_label0.set_text('''Unmount all except ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}. $(eval_gettext $'This may require several minutes...')''')"
pkill pcmanfm	#To avoid it automounts
for ((fuopimerg=1;fuopimerg<=TOTAL_QUANTITY_OF_OS;fuopimerg++)); do
	if [[ "${MNT_PATH[$fuopimerg]}" ]] && [[ "${OS_PARTITION[$fuopimerg]}" != "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" ]];then
		umount "${MNT_PATH[$fuopimerg]}"
	fi
done
}

#####Used by repair, uninstaller (for GRUB reinstall, and purge)
prepare_chroot()
{
echo "SET@_label0.set_text('''Chroot. $(eval_gettext $'This may require several minutes...')''')"
for w in dev dev/pts proc sys; do mount -B /$w "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/$w" ; done  # /dev/pts ???
mount_separate_boot_if_required
}

mount_separate_boot_if_required()
{
if [[ "$USE_SEPARATEBOOTPART" = "yes" ]];then
	echo "mount_separate_boot_if_required ${BLKIDMNT_POINT[$BOOTPART_TO_USE]}"
	mkdir -p "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"
	if [[ "$(ls "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot" )" ]];then
		echo "Warning: ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot is not empty"
	else
		echo "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot is empty"
	fi
	pkill pcmanfm	#To avoid it automounts
	if [[ -d "${BLKIDMNT_POINT[$BOOTPART_TO_USE]}/boot" ]];then
		umount "${BLKIDMNT_POINT[$BOOTPART_TO_USE]}"
		mount "/dev/${LISTOFPARTITIONS[$BOOTPART_TO_USE]}/boot" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"
		echo "Mounted /dev/${LISTOFPARTITIONS[$BOOTPART_TO_USE]}/boot on ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"
	else
		umount "${BLKIDMNT_POINT[$BOOTPART_TO_USE]}"
		mount "/dev/${LISTOFPARTITIONS[$BOOTPART_TO_USE]}" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"
		echo "Mounted /dev/${LISTOFPARTITIONS[$BOOTPART_TO_USE]} on ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"		
	fi
fi
if [[ "$GRUBPACKAGE" = "grub-efi" ]];then
	echo "mount EFI boot ${BLKIDMNT_POINT[$EFIPART_TO_USE]}"
	if [[ ! -d "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi/efi" ]];then #https://wiki.archlinux.org/index.php/GRUB2#UEFI_systems
		mkdir -p "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi/efi"
		echo "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi/efi was created"
	fi
	pkill pcmanfm	#To avoid it automounts
	umount "${BLKIDMNT_POINT[$EFIPART_TO_USE]}"
	mount "/dev/${LISTOFPARTITIONS[$EFIPART_TO_USE]}" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi"
	echo "Mounted the EFI partition /dev/${LISTOFPARTITIONS[$EFIPART_TO_USE]} on ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi"
fi
}

unmount_separate_boot_if_required()
{
if [[ "$USE_SEPARATEBOOTPART" = "yes" ]];then
	pkill pcmanfm	#To avoid it automounts
	umount "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot"
fi
if [[ "$GRUBPACKAGE" = "grub-efi" ]];then
	pkill pcmanfm	#To avoid it automounts
	umount "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/efi"
fi
}

#####Used by repair, uninstaller (for GRUB reinstall, and purge)
unchroot_linux_to_reinstall()
{
echo "SET@_label0.set_text('''Unchroot. $(eval_gettext $'Please wait few seconds...')''')"
unmount_separate_boot_if_required
pkill pcmanfm	#To avoid it automounts
for w in dev/pts dev proc sys; do umount "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/$w" ; done
}


########################################### PURGE GRUB ##################################################################
purge_grub()
{
echo "SET@_label0.set_text('''$Purge_and_reinstall_the_grub_of ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]}. $(eval_gettext $'This may require several minutes...')''')"
PART_TO_REINSTALL_GRUB="$PART_TO_REINSTALL_GRUB_PURGE"
echo "Purge the GRUB of ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]}"
force_unmount_os_partitions_in_mnt_except_reinstall_grub
echo "SET@_purgewindow.set_title('''$(eval_gettext "$CLEANNAME")''')"
echo "SET@_purgewindow.set_icon_from_file('''$APPNAME.png''')"
cp "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" $TMP_FOLDER/${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}/grub_before_purge #Security
if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
	activate_all_repositories
	dpkg_function
	update_function
	VALIDSOURCE="$(LANGUAGE=C LC_ALL=C apt-cache policy $GRUBPACKAGE | grep Candidate )"
else
	prepare_chroot
	mv "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf.old"
	cp /etc/resolv.conf "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf"  # Required to connect to the Internet.
	activate_all_repositories "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}"
	dpkg_function
	update_function
	VALIDSOURCE="$(LANGUAGE=C LC_ALL=C chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" apt-cache policy $GRUBPACKAGE | grep Candidate )"
fi
if [[ "$GRUBPACKAGE" = "grub-pc" ]];then
	check_deb_install_feasibility "grub-gfxpayload-lists grub-pc-bin grub2-common" "$PART_TO_REINSTALL_GRUB"
else
	check_deb_install_feasibility "efibootmgr grub-efi-ia32 grub-efi-amd64 grub-efi-ia32-bin grub-efi-amd64-bin" "$PART_TO_REINSTALL_GRUB"
fi
check_deb_install_feasibility "$GRUBPACKAGE grub-common ucf debconf" "$PART_TO_REINSTALL_GRUB"
echo "VALIDSOURCE $VALIDSOURCE , DEBCHECK $DEBCHECK"
if [[ ! "$VALIDSOURCE" ]] || [[ "$(grep "\(none\)" <<< "$VALIDSOURCE" )" ]] || [[ "$DEBCHECK" = "debNG" ]];then
	restore_original_repositories "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}"
	end_of_pulsate
	if [[ ! "$VALIDSOURCE" ]] || [[ "$(grep "\(none\)" <<< "$VALIDSOURCE" )" ]];then
		if [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/apt/sources.list" ]];then
			echo "No valid source for $GRUBPACKAGE"
			xdg-open "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/apt/sources.list" &
			zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="Please enable a repository for the [${GRUBPACKAGE}] package in your Software Sources. Then try again."
		else
			echo "No ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/apt/sources.list"
			zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="Please create a ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/apt/sources.list file with a source for the [${GRUBPACKAGE}] package. Then try again."
		fi
	else
		zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${Please_close_all_your_package_managers} (${Software_Centre}, ${Update_Manager}, Synaptic, ...). ${Then_try_again}"
	fi
	echo 'SET@_mainwindow.show()'
else
	if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
		if [[ -f /usr/sbin/grub-install ]];then
			echo "SET@_label8.set_text('''$Please_open_a_terminal_then_type_the_following_command''')"
			grub-install -v #Debug
			echo "SET@_label9.set_text('''sudo apt-get purge --force-yes -y grub grub-pc grub-efi grub-common''')"
			echo "SET@_label10.set_text('''\\n${Then_choose_Yes_when_the_below_window_appears}\\n''')"
		else  # GRUB already missing
			if [[ ! "$(ls "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/grub" | grep -i efi)" ]];then
				rm -r "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/grub"
#In case the user had modified something manually the folder would have remained. For EFI, better leave it (in case there are Windows files)
			fi
			rm -rf "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/grub.d/proxifiedScripts/linux" #Solves bug887761 due to Grub-Customizer
			echo "SET@_label8.set_text('''$Now_please_type_this_command_in_the_terminal''')"
			echo "SET@_label9.set_text('''sudo apt-get install --force-yes -y $GRUBPACKAGE''')"
			echo "SET@_label10.set_text('''\\n${Then_select_correct_device_when_the_below_window_appears}\\n''')"
			echo 'SET@_hbox9.hide()'; echo 'SET@_hbox10.show()'
			echo 'SET@_button6.hide()'; echo 'SET@_button8.hide()'; echo 'SET@_button7.show()';echo 'SET@_button9.show()';
		fi
	else
		if [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/usr/sbin/grub-install" ]] || [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/usr/sbin/update-grub" ]];then
			echo "SET@_label8.set_text('''$Please_open_a_terminal_then_type_the_following_command''')"
			chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" grub-install -v #Debug
			echo "SET@_label9.set_text('''sudo chroot \"${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}\" apt-get purge --force-yes -y grub grub-pc grub-efi grub-common''')"
			echo "SET@_label10.set_text('''\\n${Then_choose_Yes_when_the_below_window_appears}\\n''')"
		else  # GRUB already missing
			echo "SET@_label8.set_text('''$Now_please_type_this_command_in_the_terminal''')"
			echo "SET@_label9.set_text('''sudo chroot \"${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}\" apt-get install --force-yes -y $GRUBPACKAGE''')"
			echo "SET@_label10.set_text('''\\n${Then_select_correct_device_when_the_below_window_appears}\\n''')"
			echo 'SET@_hbox9.hide()'; echo 'SET@_hbox10.show()'
			echo 'SET@_button6.hide()'; echo 'SET@_button8.hide()'; echo 'SET@_button7.show()';echo 'SET@_button9.show()';
		fi
	fi
	end_of_pulsate
	echo 'SET@_purgewindow.show()'
fi
}


check_deb_install_feasibility()
{
#$1:DEBs $2:part
DEBCHECK="debOK"
if [[ "${LISTOFPARTITIONS[$2]}" = "$CURRENTSESSIONPARTITION" ]];then
	for DEBTOCHECK in $1;do
		rm -f /var/cache/apt/archives/${DEBTOCHECK}_*
		apt-get -dy install --reinstall $DEBTOCHECK || DEBCHECK="debNG" #internet KO or dpkg blocked (e.g. Synaptic is open)
	done
else
	for w in dev dev/pts proc sys; do mount -B /$w "${BLKIDMNT_POINT[$2]}/$w"; done
	for DEBTOCHECK in $1;do
		rm -f ${BLKIDMNT_POINT[$2]}/var/cache/apt/archives/${DEBTOCHECK}_*
		chroot "${BLKIDMNT_POINT[$2]}" apt-get -dy install --reinstall $DEBTOCHECK || DEBCHECK="debNG"
	done
	for w in dev/pts dev proc sys; do umount "${BLKIDMNT_POINT[$2]}/$w"; done
fi
echo "DEBCHECK $DEBCHECK, $1, ${LISTOFPARTITIONS[$2]}"
}

#First cancel button of Purge GRUB process
_button6()
{
quit_purge
zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$No_change_have_been_performed_on_your_computer_See_you_soon"
echo 'EXIT@@'
}

#Second cancel button of Purge GRUB process
_button7()
{
quit_purge
zenity --warning --text="${GRUB_reinstallation_has_been_cancelled}\\n ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]} ${is_now_without_GRUB}"
echo 'EXIT@@'
}

#Called by cancel buttons of Purge GRUB process
quit_purge()
{
echo "SET@pulsatewindow.set_title('''${Scanning_systems}''')"; 
echo 'SET@_purgewindow.hide()'
beginning_of_pulsate
restore_original_repositories "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}"
echo "GRUB reinstallation not performed by the user after Purge : the system will remain without any GRUB"
sleep 10 # In case an operation in the user terminal was not finished
restore_resolvconf_and_unchroot
mount_all_blkid_partitions_except_df ; echo "Mount all the partitions for the logs"
save_log_on_disks ; unmount_all_blkid_partitions_except_df; 
end_of_pulsate; 
}

#Called by purge GRUB
restore_resolvconf_and_unchroot()
{
if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" != "$CURRENTSESSIONPARTITION" ]];then
	rm "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf"
	mv "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf.old" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/resolv.conf"
	unchroot_linux_to_reinstall
fi
}

#Called by purge GRUB
_button8()
{
check_internet_connection
if [[ "$INTERNET" = "no connection" ]];then # In case connexion is cut after instructions
	echo "SET@_label11.set_text('''${No_internet_connection_detected}''')"
	echo 'SET@_label11.show()'; sleep 2; echo 'SET@_label11.hide()'
elif [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/usr/sbin/grub-install" ]] || [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/usr/sbin/update-grub" ]];then
	echo "SET@_label11.set_text('''\\n${GRUB_is_still_present} ${Please_try_again}''')"
	echo 'SET@_label11.show()'; sleep 2; echo 'SET@_label11.hide()'
else
	echo "SET@_label8.set_text('''$Now_please_type_this_command_in_the_terminal''')"
	rm -r "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/boot/grub"	#In case the user had modified something manually the folder would have remained
	if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
		echo "SET@_label9.set_text('''sudo apt-get install --force-yes -y $GRUBPACKAGE''')"
	else
		echo "SET@_label9.set_text('''sudo chroot \"${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}\" apt-get install --force-yes -y $GRUBPACKAGE''')"
	fi
	echo "SET@_label10.set_text('''${Then_select_correct_device_when_the_below_window_appears}''')"
	echo 'SET@_hbox9.hide()'; echo 'SET@_hbox10.show()'
	echo 'SET@_button6.hide()'; echo 'SET@_button8.hide()'; echo 'SET@_button7.show()';echo 'SET@_button9.show()';
fi
}

#Called by purge GRUB
_button9()
{
check_internet_connection
if [[ ! -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/usr/sbin/grub-install" ]];then
	echo "SET@_label11.set_text('''\\n${GRUB_is_still_absent} ${Please_try_again}''')"
	echo 'SET@_label11.show()'; sleep 2; echo 'SET@_label11.hide()'
else
	# Reinstallation successful
	echo 'SET@_purgewindow.hide()'
	beginning_of_pulsate
	sleep 20 # To avoid unmounting before the update is finished
	if [[ "$UNCOMMENT_GFXMODE" = "yes" ]] || [[ "$ADD_KERNEL_OPTION" = "yes" ]];then
		if [[ "$UNCOMMENT_GFXMODE" = "yes" ]];then
			uncomment_gfxmode
		fi
		if [[ "$ADD_KERNEL_OPTION" = "yes" ]];then
			add_kernel_option
		fi
		if [[ "$UNHIDEBOOT_ACTION" = "yes" ]];then	#Because a new GRUB has been generated 
			unhide_boot_menus_etc_default_grub
		fi
		if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
			grub-install -v #Debug
			update-grub
		else
			chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" grub-install -v #Debug
			chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" update-grub
		fi
	fi
	restore_original_repositories "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}"
	restore_resolvconf_and_unchroot
	mount_all_blkid_partitions_except_df ; echo "Force mount all OS partitions for the logs"
	unmount_all_and_success_repair
fi
}


################################ UPDATE PACKAGES ACTION (USED BY PURGE_GRUB) ###################################
update_function()
{
check_internet_connection
if [[ "$INTERNET" = "connected" ]];then
	if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
		apt-get -y update
	else
		chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" apt-get -y update
	fi
else
	display_error_and_back_to_mainwindow
fi
###### Repair packages #######
#  check_internet_connection
#  if [[ "$INTERNET" = "connected" ]];then
#    if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
#      apt-get install -fy
#    else
#      chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" apt-get install -fy
#    fi
#  else
#    display_error_and_back_to_mainwindow
#  fi
}

display_error_and_back_to_mainwindow()
{
restore_resolvconf_and_unchroot
end_of_pulsate
zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="$No_internet_connection_detected"
echo 'SET@_mainwindow.show()'
}


########################################### UNCOMMENT GFXMODE ############################
uncomment_gfxmode()
{
echo "UNCOMMENT_GFXMODE of ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub"
echo "SET@_label0.set_text('''$Uncomment_GRUB_GFXMODE. $(eval_gettext $'This may require several minutes...')''')"
if [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" ]];then
	rm -f $TMP_FOLDER_TO_BE_CLEARED/grub_new
	while read line; do
		if [[ "$(grep "#GRUB_GFXMODE=" <<< $line )" ]];then
			echo "${line#*#}" >> $TMP_FOLDER_TO_BE_CLEARED/grub_new
		else
			echo "$line" >> $TMP_FOLDER_TO_BE_CLEARED/grub_new
		fi
	done < <(echo "$(< "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" )")
	cp -f "$TMP_FOLDER_TO_BE_CLEARED/grub_new" "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub"
	echo "Uncommented GFX_MODE in ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}/etc/default/grub"
fi
}

########################################### ADD KERNEL ############################
add_kernel_option()
{
echo "add_kernel_option CHOSEN_KERNEL_OPTION is : $CHOSEN_KERNEL_OPTION"
echo "SET@_label0.set_text('''$Add_a_kernel_option $CHOSEN_KERNEL_OPTION. $(eval_gettext $'This may require several minutes...')''')"
if [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" ]];then
	rm -f $TMP_FOLDER_TO_BE_CLEARED/grub_new
	while read line; do
		if [[ "$(grep "GRUB_CMDLINE_LINUX_DEFAULT=" <<< $line )" ]];then
			echo "${line%\"*} ${CHOSEN_KERNEL_OPTION}\"" >> $TMP_FOLDER_TO_BE_CLEARED/grub_new
		else
			echo "$line" >> $TMP_FOLDER_TO_BE_CLEARED/grub_new
		fi
	done < <(echo "$(< "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" )")
	cp -f $TMP_FOLDER_TO_BE_CLEARED/grub_new "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub"
	echo "Added kernel options in ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}/etc/default/grub"
fi
}

########################################### DPKG FUNCTION ############################
dpkg_function()
{
echo "dpkg_function" #Used by reinstall and purge GRUB
echo "SET@_label0.set_text('''dpkg --configure -a ${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}. $(eval_gettext $'This may require several minutes...')''')"
if [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" = "$CURRENTSESSIONPARTITION" ]];then
	dpkg --configure -a
else
	chroot "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}" dpkg --configure -a
fi
}

########################################### OPEN etc/default/grub ############################
_button_open_etc_default_grub()
{
if [[ -f "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" ]];then
	xdg-open "${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub" &
else
	echo "User tried to open ${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub but it does not exist."
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${BLKIDMNT_POINT[$PART_TO_REINSTALL_GRUB]}/etc/default/grub does not exist. Please choose the [Purge and reinstall] option."
fi
}

########################################### UNHIDE BOOT MENUS ############################
unhide_boot_menus_xp()
{
echo "Unhide boot menu (${UNHIDEBOOT_TIME} seconds) if Wubi detected"
if [[ "$QTY_WUBI" != "0" ]];then
	for ((i=1;i<=NBOFPARTITIONS;i++)); do
		if [[ -f "${BLKIDMNT_POINT[$i]}/boot.ini" ]];then
			echo "SET@_label0.set_text('''$Unhide_boot_menu. $(eval_gettext $'This may require several minutes...')''')"
			cp "${BLKIDMNT_POINT[$i]}/boot.ini" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_old"
			cp "${BLKIDMNT_POINT[$i]}/boot.ini" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new"
			MODIFDONE=""
			for line in $(cat "${BLKIDMNT_POINT[$i]}/boot.ini"); do #No " around cat
				if [[ "$(grep "timeout=" <<< "$line" )" ]] && [[ "$line" != "timeout=${UNHIDEBOOT_TIME}" ]];then
					sed -i "s/${line}.*/timeout=${UNHIDEBOOT_TIME}/" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new"
					MODIFDONE="yes"
				fi
			done
			if [[ -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new" ]] && [[ "$MODIFDONE" = "yes" ]];then #Security
				echo "Unhide Windows XP boot menu in ${LISTOFPARTITIONS[$i]}/boot.ini"
				mv "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new" "${BLKIDMNT_POINT[$i]}/boot.ini"
			elif [[ ! -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new" ]];then
				echo "Error: could not unhide XP in ${LISTOFPARTITIONS[$i]}/boot.ini"
				zenity --error --text="Error: could not unhide XP in ${LISTOFPARTITIONS[$i]}/boot.ini"
			else
				rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_old"
				rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/boot.ini_new"
			fi
		fi
	done
fi
}

unhide_boot_menus_etc_default_grub()
{
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ -f "${BLKIDMNT_POINT[$i]}/etc/default/grub" ]];then
		echo "SET@_label0.set_text('''$Unhide_boot_menu. $(eval_gettext $'This may require several minutes...')''')"
		cp "${BLKIDMNT_POINT[$i]}/etc/default/grub" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_old"
		cp "${BLKIDMNT_POINT[$i]}/etc/default/grub" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new"
		MODIFDONE=""
		for line in $(cat "${BLKIDMNT_POINT[$i]}/etc/default/grub"); do
			if [[ "$(grep "GRUB_TIMEOUT=" <<< "$line" )" ]] && [[ "$line" != "GRUB_TIMEOUT=${UNHIDEBOOT_TIME}" ]];then
				sed -i "s/${line}.*/GRUB_TIMEOUT=${UNHIDEBOOT_TIME}/" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new"
				MODIFDONE="yes" #Set timout to UNHIDEBOOT_TIME seconds
			elif [[ "$(grep "GRUB_HIDDEN_TIMEOUT=" <<< $line )" ]] && [[ ! "$(grep "#GRUB_HIDDEN_TIMEOUT=" <<< $line )" ]];then
				sed -i "s/${line}.*/#${line}/" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new"
				MODIFDONE="yes" #Comment GRUB_HIDDEN_TIMEOUT
			elif [[ "$(grep "GRUB_DISABLE_RECOVERY=" <<< $line )" ]] && [[ ! "$(grep "#GRUB_DISABLE_RECOVERY=" <<< $line )" ]];then
				sed -i "s/${line}.*/#${line}/" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new"
				MODIFDONE="yes" #Comment GRUB_DISABLE_RECOVERY
			fi
		done
		if [[ -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new" ]] && [[ "$MODIFDONE" = "yes" ]];then #Security
			echo "Unhide GRUB boot menu in ${LISTOFPARTITIONS[$i]}/etc/default/grub"
			mv "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new" "${BLKIDMNT_POINT[$i]}/etc/default/grub"
		elif [[ ! -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new" ]];then
			echo "Error: could not unhide GRUB menu in ${LISTOFPARTITIONS[$i]}/etc/default/grub"
			zenity --error --text="Error: could not unhide GRUB menu in ${LISTOFPARTITIONS[$i]}/etc/default/grub"
		else
			rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_old"
			rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/etc_default_grub_new"
		fi
	fi
done
}

unhide_boot_menus_grubcfg()
{
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ -f "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg" ]];then
		echo "SET@_label0.set_text('''$Unhide_boot_menu. $(eval_gettext $'This may require several minutes...')''')"
		cp "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_old"
		cp "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new"
		MODIFDONE=""
		for line in $(cat "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg"); do
			if [[ "$(grep "timeout=" <<< $line )" ]] && [[ "$line" != "timeout=${UNHIDEBOOT_TIME}" ]];then
				sed -i "s/${line}.*/timeout=${UNHIDEBOOT_TIME}/" "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new"
				MODIFDONE="yes" #Set timout to UNHIDEBOOT_TIME seconds
			fi
		done
		if [[ -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new" ]] && [[ "$MODIFDONE" = "yes" ]];then #Security
			echo "Unhide GRUB boot menu in ${LISTOFPARTITIONS[$i]}/boot/grub/grub.cfg"
			mv "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new" "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg"
			if [[ "$i" = "$PART_TO_REINSTALL_GRUB" ]];then
				rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_old" #Not needed
			fi
		elif [[ ! -f "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new" ]];then
			echo "Error: could not unhide GRUB menu in ${LISTOFPARTITIONS[$i]}/boot/grub/grub.cfg"
			zenity --error --text="Error: could not unhide GRUB menu in ${LISTOFPARTITIONS[$i]}/boot/grub/grub.cfg"
		else
			rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_old"
			rm "$TMP_FOLDER/${LISTOFPARTITIONS[$i]}/grub.cfg_new"
		fi
	fi
done
}

######################### USE STATS FOR IMPROVING THE TOOLS##################
stats()
{
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
	if [[ -f "${LOG_PATH[$i]}/$APPNAME" ]];then
		NEWUSER="no"
	else
		touch "${LOG_PATH[$i]}/$APPNAME"
	fi
done
if [[ ! "$NEWUSER" ]];then
	wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/nu http://sourceforge.net/projects/$APPNAME/files/statistics/$APPNAME.user.counter/download
fi
}
