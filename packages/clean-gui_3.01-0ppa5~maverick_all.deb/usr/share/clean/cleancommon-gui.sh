#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## 19/12/2011 
## Special thanks to Babdu89 and GRUB devs.

## LIBRAIRIES FOR OS-UNINSTALLER AND BOOT REPAIR
## http://ubuntuforums.org/showthread.php?t=1615667

########################## Initialization of translations ################
translations_init()
{
###To export gettext librairy
set -a
source gettext.sh
set +a
export TEXTDOMAIN=cleancommon-translations    # same .mo for boot-repair and os-uninstaller
export TEXTDOMAINDIR="/usr/share/locale"
. /usr/bin/gettext.sh
}

########################## Initialization of logs #######################
init_and_updateapp()
{
initialization
log_preparation
if [[ -f /tmp/clean_dev ]];then
	DEV="-dev"
	echo "DEV $DEV"
	rm /tmp/clean_dev
elif [[ -f /tmp/clean_debug ]];then
	DEBUG="yes"
	echo "DEBUG $DEBUG"
	rm /tmp/clean_debug
fi
update_translations
check_internet_connection
updateapp
install_needed_packages	#after updateapp
echo "SET@_label0.set_text('''$(eval_gettext $'Scanning systems'). $(eval_gettext $'This may require several minutes...')''')"
}

update_translations()
{
# Zenity (common)
Scanning_systems=$(eval_gettext $'Scanning systems')
Operation_aborted=$(eval_gettext $'Operation aborted')
do_you_want_to_update=$(eval_gettext $'Do you want to update the software?')
this_will_update_from_ppa=$(eval_gettext $'this will download and install last version from its PPA')
No_change_have_been_performed_on_your_computer_See_you_soon=$(eval_gettext $'No change have been performed on your computer. See you soon!')
No_OS_have_been_found_on_this_computer=$(eval_gettext $'No OS have been found on this computer.')
Please_use_in_live_session=$(eval_gettext $'Please use this software in a live-session (live-CD or live-USB).')
Please_use_in_a_64bits_session=$(eval_gettext $'Please use this software in a 64bits session.')
Ubuntu_installed_in_Windows_via_Wubi=$(eval_gettext $'Ubuntu installed in Windows (via Wubi)')
No_internet_connection_detected=$(eval_gettext $'No internet connection detected')
The_software_could_not_be_updated=$(eval_gettext $'The software could not be updated.')
Please_close_all_your_package_managers=$(eval_gettext $'Please close all your package managers')
Software_Centre=$(eval_gettext $'Software Center')
Update_Manager=$(eval_gettext $'Update Manager')
#/// TRANSLATORS: Please do not translate FUNCTION. Neutral and singular.
FUNCTION_detected=$(eval_gettext $'${FUNCTION} detected.')
#/// TRANSLATORS: Please do not translate [${PACKAGELIST}]
This_will_install_PACKAGELIST=$(eval_gettext $'This will install the [${PACKAGELIST}] packages.')
#/// TRANSLATORS: Please do not translate [${PACKAGELIST}]
Do_you_want_to_install_PACKAGELIST=$(eval_gettext $'Do you want to install the [${PACKAGELIST}] packages?')
#/// TRANSLATORS: Please do not translate [${PACKAGELIST}]
please_install_PACKAGELIST=$(eval_gettext $'Please install the [${PACKAGELIST}] packages.')
Do_you_want_to_continue=$(eval_gettext $'Do you want to continue?')
Then_try_again=$(eval_gettext $'Then try again.')
Please_connect_internet=$(eval_gettext $'Please connect internet.')
Then_close_this_window=$(eval_gettext $'Then close this window.')
#/// TRANSLATORS: Please do not translate [dmraid] and MDraid
dmraid_may_interfer_MDraid_remove=$(eval_gettext $'[dmraid] packages may interfer with MDraid. Do you want to remove them?')
assemble_mdraid_arrays=$(eval_gettext $'Do you want to assemble software raid (MDRaid) arrays?')
activate_dmraid=$(eval_gettext $'Do you want to activate [dmraid] (fakeraid)?')

#glade2script chains (Common)
Please_wait=$(eval_gettext $'Please wait few seconds...')
#/// TRANSLATORS: this string must be as short as possible
The_system_now_in_use=$(eval_gettext $'The OS now in use')
Advanced_options=$(eval_gettext $'Advanced options')
Main_options=$(eval_gettext $'Main options')
GRUB_location=$(eval_gettext $'GRUB location')
GRUB_options=$(eval_gettext $'GRUB options')
MBR_options=$(eval_gettext $'MBR options')
Other_options=$(eval_gettext $'Other options')
Reinstall_GRUB=$(eval_gettext $'Reinstall GRUB')
Restore_MBR=$(eval_gettext $'Restore MBR')
Unhide_boot_menu=$(eval_gettext $'Unhide boot menu')
seconds=$(eval_gettext $'seconds')
Restore_the_MBR_of=$(eval_gettext $'Restore the MBR of:')
Partition_booted_by_the_MBR=$(eval_gettext $'Partition booted by the MBR:')
OS_to_boot_by_default=$(eval_gettext $'OS to boot by default:')
Purge_and_reinstall_the_grub_of=$(eval_gettext $'Purge and reinstall the GRUB of:')
#/// TRANSLATORS: Please do not translate /boot
Separate_boot_partition=$(eval_gettext $'Separate /boot partition:')
#/// TRANSLATORS: Please do not translate /boot/efi
EFI_partition=$(eval_gettext $'Separate /boot/efi partition:')
Place_GRUB_in_all_disks=$(eval_gettext $'Place GRUB in all disks')
except_USB_disks_without_OS=$(eval_gettext $'except USB disks without OS')
is_a_removable_disk=$(eval_gettext $'is a removable disk.')
Place_GRUB_into=$(eval_gettext $'Place GRUB into:')
Force_GRUB_into=$(eval_gettext $'Force GRUB into:')
for_chainloader=$(eval_gettext $'for chainloader')
Blank_extra_space=$(eval_gettext $'Reset extra space after MBR')
Warning_blankextra=$(eval_gettext $'Warning: some applications using DRM or some OEM system tools may not work afterwards.')
#/// TRANSLATORS: Please do not translate GRUB_GFXMODE
Uncomment_GRUB_GFXMODE=$(eval_gettext $'Uncomment GRUB_GFXMODE')
Ata_disk=$(eval_gettext $'ATA disk support')
#/// TRANSLATORS: Please do not translate [${BUG}]
solves_BUG=$(eval_gettext $'solves the [${BUG}] error')
Add_a_kernel_option=$(eval_gettext $'Add a kernel option:')
Edit_GRUB_configuration_file=$(eval_gettext $'Edit GRUB configuration file')
Applying_changes=$(eval_gettext $'Applying changes.')
This_may_require_several_minutes=$(eval_gettext $'This may require several minutes...')
This_will_enable_this_feature=$(eval_gettext $'This will enable this feature.')
Checking_updates=$(eval_gettext $'Checking updates')
Updating=$(eval_gettext $'Updating')
#/// TRANSLATORS: Please do not translate ${FUNCTION}
Enabling_FUNCTION=$(eval_gettext $'Enabling ${FUNCTION}')
Translate=$(eval_gettext $'Translate')
Thanks=$(eval_gettext $'Credits')
Backup_table=$(eval_gettext $'Backup partition tables, bootsectors and logs')
Participate_stats=$(eval_gettext $'Participate to statistics of use')
Please_choose_folder_to_put_backup=$(eval_gettext $'Please choose a folder to put the backup into.')
USB_disk_recommended=$(eval_gettext $'It is recommended to choose a USB disk.')

if [[ "$APPNAME" = "boot-repair" ]];then
	update_translations_br
else
	update_translations_os
fi
}

########################################### CHECK INTERNET CONNECTION ############################################
check_internet_connection()
{
if [[ "$(wget -q -O - checkip.dyndns.org|grep 'Current IP Address:')" ]];then INTERNET="connected";else INTERNET="no connection";fi
echo "internet: $INTERNET"
}

########################################### UPDATE & INSTALL APP PACKAGES ############################################
updateapp()
{
temp=$(LANGUAGE=C LC_ALL=C apt-cache policy clean-gui | grep Installed )
COMMONGUI_VERSION=${temp#* Installed: };echo "clean-gui version : $COMMONGUI_VERSION"
if [[ -f /tmp/clean_reboot ]];then
	rm /tmp/clean_reboot
else
	UPPDATE="/tmp/update${APPNAME}$(date +'%Y-%m-%d_%H')"
	if [[ ! -f ${UPPDATE} ]]; then	# No update during 1~59 minutes
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${do_you_want_to_update} (${this_will_update_from_ppa})" || choice="noupdate"
		beginning_of_pulsate
		if [[ "$choice" != "noupdate" ]];then
			ask_internet_connection
			if [[ "$INTERNET" = "connected" ]] && [[ ! "$DEBUG" ]];then
				echo "SET@_label0.set_text('''$(eval_gettext $'Checking updates'). $(eval_gettext $'This may require several minutes...')''')"
				PSP_VERSION="0.60" #default (also Debian stable version)
				if [[ $(type apt-add-repository) ]];then
					rm /etc/apt/sources.list.d/yannubuntu-${APPNAME}*	#In case the file was corrupted
					temp=$(LANGUAGE=C LC_ALL=C apt-cache policy python-software-properties | grep Installed );
					PSP_VERSION=${temp#* Installed: };echo "python-software-properties version : $PSP_VERSION"
				fi
				if [[ "$(grep "0.7[5-9]" <<< "$PSP_VERSION" )" ]] || [[ "$(grep "0.[8-9][0-9]" <<< "$PSP_VERSION" )" ]];then
					if [[ "$(grep "0.7[5-9]" <<< "$PSP_VERSION" )" ]] || [[ "$(grep "0.80" <<< "$PSP_VERSION" )" ]];then
						add-apt-repository ppa:yannubuntu/${APPNAME}${DEV}
					else
						add-apt-repository -y ppa:yannubuntu/${APPNAME}${DEV}
					fi
					loop_updateapp
					#rm /etc/apt/sources.list.d/yannubuntu-${APPNAME}*
				elif [[ -f "/etc/apt/sources.list" ]];then #and PSP < 0.75
					for vvv in lucid oneiric;do	#to avoid python dep error
						PPADEB="deb http://ppa.launchpad.net/yannubuntu/${APPNAME}${DEV}/ubuntu ${vvv} main"
						if [[ ! "$(cat /etc/apt/sources.list | grep "${PPADEB}" )" ]] || [[ "$(cat /etc/apt/sources.list | grep "#${PPADEB}" )" ]] || [[ "$(cat /etc/apt/sources.list | grep "# ${PPADEB}" )" ]];then
							cp /etc/apt/sources.list $TMP_FOLDER/sources.list
							echo "${PPADEB}" >> /etc/apt/sources.list
							loop_updateapp
							#restore_original_repositories
						else
							loop_updateapp
						fi
					done
				else
					echo "Warning: no /etc/apt/sources.list"
				fi
				if [[ "$choice" = "exit" ]];then
					echo 'EXIT@@'
				elif [[ "$choice" != "noupdate" ]];then
					touch ${UPPDATE}	# To avoid useless update next time the tool is used
					temp=$(LANGUAGE=C LC_ALL=C apt-cache policy $APPNAME | grep Installed ); APPNAME_NEW=${temp#* Installed: }
					temp=$(LANGUAGE=C LC_ALL=C apt-cache policy clean | grep Installed ); COMMON_NEW=${temp#* Installed: }
					temp=$(LANGUAGE=C LC_ALL=C apt-cache policy clean-gui | grep Installed ); COMMONGUI_NEW=${temp#* Installed: }
					if [[ "$APPNAME_NEW" != "$APPNAME_VERSION" ]] || [[ "$COMMON_NEW" != "$COMMON_VERSION" ]] || [[ "$COMMONGUI_NEW" != "$COMMONGUI_VERSION" ]];then
						echo "${APPNAME} has been updated"
						end_of_pulsate
						touch /tmp/clean_reboot
						choice="exit"; echo 'EXIT@@'
					fi
				fi
			else
				end_of_pulsate
				zenity --warning --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}. ${The_software_could_not_be_updated}"
				beginning_of_pulsate
			fi
		fi
	fi
fi
}

loop_updateapp()
{
echo "SET@_label0.set_text('''$(eval_gettext $'Updating'). $(eval_gettext $'This may require several minutes...')''')"
UPDATEFUNC="apt-get install -y --force-yes clean clean-gui $APPNAME"
temp=$(apt-get -y update)
temp=$($UPDATEFUNC) #double update to avoid dpkg block when moving file from DEB to another
if [[ ! "$($UPDATEFUNC)" ]];then
	end_of_pulsate
	zenity --warning --title="$(eval_gettext "$CLEANNAME")" --text="${Please_close_all_your_package_managers} (${Software_Centre}, ${Update_Manager}, Synaptic, ...). ${Then_try_again}"
	echo "APT blocked"
	choice="exit"
fi
}

install_needed_packages()
{
BLKID=$(blkid)
if [[ "$(grep "LVM" <<< "$BLKID" )" ]];then
	FUNCTION="LVM"
	update_translations
	echo "SET@_label0.set_text('''$(eval_gettext $'Enabling ${FUNCTION}'). $(eval_gettext $'This may require several minutes...')''')"
	if [[ ! "$(type lvscan)" ]] || [[ ! "$(type vgchange)" ]];then
		echo "LVM2 package needed"
		PACKAGELIST="lvm2"
		update_translations
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${FUNCTION_detected} ${Do_you_want_to_install_PACKAGELIST}" || lvmenable="no"
		beginning_of_pulsate
		if [[ "$lvmenable" != "no" ]];then
			ask_internet_connection
			if [[ "$INTERNET" = "connected" ]];then
				apt-get install -y --force-yes lvm2
			else
				end_of_pulsate
				zenity --warning --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}."
				beginning_of_pulsate
			fi
		fi
	fi
	if [[ ! "$(type lvscan)" ]] || [[ ! "$(type vgchange)" ]];then
		end_of_pulsate
		zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST} ${Then_try_again}"
		choice="exit"; echo 'EXIT@@'
	else
		echo "LVBKID $BLKID"
		echo "MODPROBE"
		modprobe dm-mod		# Not sure it is necessary
		echo "VGSCAN"
		vgscan --mknodes	# Not sure it is necessary
		echo "VGCHANGE"
		vgchange -ay		# Activate volumes
		LVSCAN="$(LANGUAGE=C LC_ALL=C lvscan)"
		echo "LVSCAN: $LVSCAN"
		if [[ "$(grep "inactive" <<< "$LVSCAN" )" ]];then
			echo "Warning: inactive LVM"
		fi
	fi
fi
if [[ "$(grep "raid" <<< "$BLKID" )" ]] || [[ "$(grep "/dev/mapper/" <<< "$BLKID" )" ]];then
	FUNCTION="RAID"
	echo "RAIDBKID $BLKID"
	update_translations
	echo "SET@_label0.set_text('''$(eval_gettext $'Enabling ${FUNCTION}'). $(eval_gettext $'This may require several minutes...')''')"
	if [[ ! "$(type mdadm)" ]];then
		PACKAGELIST="mdadm"
		update_translations
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${FUNCTION_detected} ${Do_you_want_to_install_PACKAGELIST} (software raid)" || mdadminstall="no"
		beginning_of_pulsate
		if [[ "$mdadminstall" != "no" ]]; then
			echo "mdadm package needed"
			ask_internet_connection
			if [[ "$INTERNET" = "connected" ]];then #/etc/mdadm/mdadm.conf defines arrays
				apt-get install -y --force-yes mdadm --no-install-recommends
			else
				end_of_pulsate
				zenity --warning --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}."
				beginning_of_pulsate
			fi
			if [[ ! "$(type mdadm)" ]];then
				end_of_pulsate
				zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST} ${Then_try_again}"
				choice="exit"; echo 'EXIT@@'
			fi
		fi
	fi
	if [[ "$(type mdadm)" ]] && [[ "$choice" != "exit" ]];then
		if [[ "$(type dmraid)" ]];then	#http://ubuntuforums.org/showthread.php?t=1551087
			removedmraid="yes"
			end_of_pulsate
			zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${dmraid_may_interfer_MDraid_remove}" || removedmraid="no"
			beginning_of_pulsate
			if [[ "$removedmraid" = "yes" ]]; then
				apt-get remove -y --force-yes dmraid
			fi
		fi
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${FUNCTION_detected} ${assemble_mdraid_arrays} (mdadm --assemble --scan)" || mdadmenable="no"
		beginning_of_pulsate
		if [[ "$mdadmenable" != "no" ]]; then
			echo "Scanning MDraid Partitions"
			mdadm --assemble --scan 	# Assemble all arrays
			# All arrays.
			MD_ARRAY=$(mdadm --detail --scan) #TODO  | ${AWK} '{ print $2 }')
			echo "MD_ARRAY $MD_ARRAY"
			#for MD in ${MD_ARRAY}; do
			#	MD_SIZE=$(fdisks ${MD})     # size in blocks
			#	MD_SIZE=$((2*${MD_SIZE}))   # size in sectors
			#	MDNAME=${MD:5}
			#	MDMOUNTNAME="MDRaid/${name}"
			#	echo "MD${MD}: ${MDNAME}, ${MDMOUNTNAME}, ${MD_SIZE}"
			#done
		fi
	fi
	if [[ ! "$(type dmraid)" ]] && [[ "$removedmraid" != "yes" ]] && [[ "$choice" != "exit" ]];then
		PACKAGELIST="dmraid"
		update_translations
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${FUNCTION_detected} ${Do_you_want_to_install_PACKAGELIST} (fakeraid)" || dmraidinstall="no"
		beginning_of_pulsate
		if [[ "$dmraidinstall" != "no" ]]; then
			echo "dmraid package needed"
			ask_internet_connection
			if [[ "$INTERNET" = "connected" ]];then
				apt-get install -y --force-yes dmraid
			else
				end_of_pulsate
				zenity --warning --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}."
				beginning_of_pulsate
			fi
			if [[ ! "$(type dmraid)" ]];then
				end_of_pulsate
				zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST} ${Then_try_again}"
				choice="exit"; echo 'EXIT@@'
			fi
		fi
	fi
	if [[ "$(type dmraid)" ]] && [[ "$choice" != "exit" ]];then
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${FUNCTION_detected} ${activate_dmraid} (dmraid -ay; dmraid -sa -c)" || dmraidenable="no"
		beginning_of_pulsate
		if [[ "$dmraidenable" != "no" ]]; then
			DMRAID="$(dmraid -si -c)"
 			if [[ "$DMRAID" = "no raid disks" ]];then
				DMRAID=""
				echo "No RAID disk"
 			else
				dmraid -ay	#Activate RAID
				DMRAID="$(dmraid -sa -c)"
				echo "DMRAID $DMRAID"	#e.g. isw_bcbggbcebj_ARRAY
			fi
		fi
	fi
fi
}

ask_internet_connection()
{
if [[ "$INTERNET" != "connected" ]];then
	end_of_pulsate
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${Please_connect_internet} ${Then_close_this_window}"
	beginning_of_pulsate
	check_internet_connection
fi
}

############################ Main function for GUI preparation ####################
check_os_and_mount_blkid_partitions_gui()
{
update_translations
echo "SET@_label0.set_text('''Os-prober. $(eval_gettext $'This may require several minutes...')''')"
delete_tmp_folder_to_be_cleared_and_update_osprober
echo "SET@_label0.set_text('''Mount. $(eval_gettext $'This may require several minutes...')''')"
if [[ ! "$DEBUG" ]];then
check_if_live_session			#After update_translation and update_osprober, and before check_os_names
check_os_and_mount_blkid_partitions
echo "SET@_label0.set_text('''$(eval_gettext $'Scanning systems'). $(eval_gettext $'This may require several minutes...')''')"
determine_part_with_os			#Used by check_part_types and check_separate_boot_partitions
check_part_types			#After mount_all_blkid_partitions_except_df and determine_part_uuid
check_wubi_existence			#After mount_all_blkid_partitions_except_df
check_separate_boot_partitions
check_gpt
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	echo "${LISTOFPARTITIONS[$i]} : ${DISK_PART[$i]}, ${PART_WITH_SEPARATEBOOT[$i]}, ${TYPE_OF_PART[$i]}, ${APTGET_TYP_OF_PART[$i]}, ${ARCH_OF_PART[$i]}, ${BOOTPRESENCE_OF_PART[$i]}, ${BLKIDMNT_POINT[$i]}, ${PART_WITH_OS[$i]}, ${GPTTYPE[$i]}, ${EFI_IN_FSTAB_OF_PART[$i]}, ${CHECKPURGE[$i]}."
done
echo "PARTED: $(LANGUAGE=C LC_ALL=C parted -l)" #debug
echo "MOUNT $MOUNTB"
echo "SET@_label0.set_text('''$(eval_gettext $'Scanning systems'). $(eval_gettext $'Please wait few seconds...')''')"

#debug
a=/sys/block/;for x in $(ls $a);do if [ ! $(grep ram<<<$x) ] && [ ! $(grep oop<<<$x) ];then b="";for y in $(ls $a$x);do b="$b $y";done;echo "$a$x: $b";fi;done #debug
a="";for x in $(ls /dev);do if [ ! $(grep oop<<<$x) ] && [ ! $(grep ram<<<$x) ] && [ ! $(grep tty<<<$x) ] && [ ! $(grep vcs<<<$x) ];then a="$a $x";fi;done;echo "/dev: $a" #debug
for y in /dev/mapper /boot/efi; do if [ -d $y ];then a="";for x in $(ls $y);do a="$a $x";done;echo "$y: $a";fi;done #debug

fi
}

####################################### DETERMINE PARTNB FROM A PARTNAME ################
determine_partnb()
{
#Example of input : "sda1"
for ((partnbi=1;partnbi<=NBOFPARTITIONS;partnbi++)); do
	if [[ "$1" = "${LISTOFPARTITIONS[$partnbi]}" ]];then
		PARTNB="$partnbi"
	fi
done
}

###################################### Check MBR to restore ###########################
check_which_mbr_can_be_restored()
{
check_available_target_partition_for_generic_mbr
NB_MBR_CAN_BE_RESTORED=0
for ((i=1;i<=NBOFDISKS;i++)); do
	if [[ "${LISTOFDISKS[$i]}" = "$CHOSEN_DISK" ]];then
		loop_check_which_mbr_can_be_restored
	fi
done
for ((i=1;i<=NBOFDISKS;i++)); do
	if [[ "${LISTOFDISKS[$i]}" != "$CHOSEN_DISK" ]];then
		loop_check_which_mbr_can_be_restored
	fi
done
#for ((i=1;i<=NB_MBR_CAN_BE_RESTORED;i++)); do echo "MBR that can be restored number $i : ${MBR_CAN_BE_RESTORED[$i]}"; done
}

loop_check_which_mbr_can_be_restored()
{
if [[ "${TARGET_PARTITION_IS_AVAILABLE[$i]}" = "yes" ]];then
	for j in $(dir /usr/lib/syslinux | grep "mbr" ); do
		if [[ "$(grep "mbr" <<< $j )" ]] && [[ "$(grep ".bin" <<< $j )" ]] && [[ ! "$(grep "[a-z]mbr" <<< $j )" ]];then
			(( NB_MBR_CAN_BE_RESTORED += 1 ))
			MBR_CAN_BE_RESTORED[$NB_MBR_CAN_BE_RESTORED]="${LISTOFDISKS[$i]} (${j%.bin})"
		fi
	done
	for j in $(dir /usr/lib/syslinux | grep "mbr" ); do
		if [[ "$(grep "mbr" <<< $j )" ]] && [[ "$(grep ".bin" <<< $j )" ]] && [[ "$(grep "[a-z]mbr" <<< $j )" ]];then
			(( NB_MBR_CAN_BE_RESTORED += 1 ))
			MBR_CAN_BE_RESTORED[$NB_MBR_CAN_BE_RESTORED]="${LISTOFDISKS[$i]} (${j%.bin})"
		fi
	done
fi
for ((j=1;j<=QTY_OF_DISKS_WITH_BACKUP;j++)); do
	if [[ "${DISKS_WITH_BACKUP[$j]}" = "${LISTOFDISKS[$i]}" ]];then
		for k in $(dir "$TMP_FOLDER/${DISKS_WITH_BACKUP[$j]}"); do
			if [[ "$(grep "mbr-" <<< $k )" ]];then
				(( NB_MBR_CAN_BE_RESTORED += 1 )); 
				MBR_CAN_BE_RESTORED[$NB_MBR_CAN_BE_RESTORED]="${LISTOFDISKS[$i]} \($(cut -c5-14 <<< $k ) $(cut -c17-21 <<< $k )\)"
				##Keeps the date in the name (mbr-YYYY-MM-DD__HH:MM*.img)
			fi
		done
	fi
done
if [[ "${TARGET_PARTITION_IS_AVAILABLE[$i]}" = "yes" ]];then
	(( NB_MBR_CAN_BE_RESTORED += 1 ))
	MBR_CAN_BE_RESTORED[$NB_MBR_CAN_BE_RESTORED]="${LISTOFDISKS[$i]} (xp generic)"
fi
}


######################################### CHECK IF LIVE-SESSION ###############################
# inputs : none
# outputs : $LIVE-SESSION
check_if_live_session()
{
if [ "$(grep -E '(boot=casper)|(boot=live)' /proc/cmdline)" ];then
	LIVESESSION="yes"
else 
	LIVESESSION="no"
	DISTRIB_DESCRIPTION="$(lsb_release -d -s)"
	CURRENTSESSIONNAME="${The_system_now_in_use} - ${DISTRIB_DESCRIPTION}"
	DFROOT=$(df / | grep "/dev/" ); DFROOT=${DFROOT%% *}
	CURRENTSESSIONPARTITION="${DFROOT#*v/}"
	#Add CurrentSession at the beginning of OSPROBER (so that GRUB reinstall of CurrentSession is selected by default)
	echo "/dev/${CURRENTSESSIONPARTITION}:${CURRENTSESSIONNAME} CurrentSession:linux" >$TMP_FOLDER_TO_BE_CLEARED/osprober_with_currentsession
	echo "$OSPROBER" >> $TMP_FOLDER_TO_BE_CLEARED/osprober_with_currentsession
	OSPROBER=$(< $TMP_FOLDER_TO_BE_CLEARED/osprober_with_currentsession)
fi
echo "LIVESESSION is : $LIVESESSION"
}

######################################### CHECK IF WUBI ###############################
check_wubi_existence()
{
TOTAL_QTY_OF_OS_INCLUDING_WUBI="$TOTAL_QUANTITY_OF_OS"; QTY_WUBI=0
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ -f "${BLKIDMNT_POINT[$i]}/ubuntu/disks/root.disk" ]] ;then
		echo "There is Wubi inside ${LISTOFPARTITIONS[$i]}"
		(( TOTAL_QTY_OF_OS_INCLUDING_WUBI += 1 )); (( QTY_WUBI += 1 ))
		OS_NAME[$TOTAL_QTY_OF_OS_INCLUDING_WUBI]="$Ubuntu_installed_in_Windows_via_Wubi"
		OS_PARTITION[$TOTAL_QTY_OF_OS_INCLUDING_WUBI]="${LISTOFPARTITIONS[$i]}"
		WUBI[$QTY_WUBI]="$TOTAL_QTY_OF_OS_INCLUDING_WUBI"
		WUBI_PART[$QTY_WUBI]="$i"
	fi
done
}

######################################### CHECK PART TYPES ###############################
determine_part_with_os()
{
#used by check_separate_boot_partitions & check_part_types
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	PART_WITH_OS[$i]="no-os"
	for ((j=1;j<=TOTAL_QUANTITY_OF_OS;j++)); do
		if [[ "${LISTOFPARTITIONS[$i]}" = "${OS_PARTITION[$j]}" ]];then
			PART_WITH_OS[$i]="with-os"
		fi
	done
	if [[ -d "${BLKIDMNT_POINT[$i]}/selinux" ]];then
		PART_WITH_OS[$i]="with-os"
	fi
	#echo "PART_WITH_OS of ${LISTOFPARTITIONS[$i]} : ${PART_WITH_OS[$i]}"
done
for ((n=1;n<=NBOFDISKS;n++)); do
	for ((i=1;i<=NBOFPARTITIONS;i++)); do
		if [[ "${PART_WITH_OS[$i]}" = "with-os" ]] && [[ "${DISK_PART[$i]}" = "${LISTOFDISKS[$n]}" ]];then
			echo "${LISTOFDISKS[$n]} contains minimum one OS"
			DISK_WITHOS[$n]="with-os"
			break
		fi
	done
done
}

check_part_types()
{
QTY_OF_PART_WITH_GRUB=0
QTY_OF_PART_WITH_APTGET=0
QTY_OF_32BITS_PART=0
QTY_OF_64BITS_PART=0
for ((i=1;i<=NBOFPARTITIONS;i++)); do 
	if [[ -f "${BLKIDMNT_POINT[$i]}/usr/sbin/grub-install" ]] && [[ -f "${BLKIDMNT_POINT[$i]}/usr/sbin/update-grub" ]]; then
		TYPE_OF_PART[$i]="grub"
		(( QTY_OF_PART_WITH_GRUB += 1 ))
		LIST_OF_PART_WITH_GRUB[$QTY_OF_PART_WITH_GRUB]="$i"
	else
		TYPE_OF_PART[$i]="no-grub"
	fi
	if [[ -f "${BLKIDMNT_POINT[$i]}/usr/bin/apt-get" ]];then
		APTGET_TYP_OF_PART[$i]="aptget"
		(( QTY_OF_PART_WITH_APTGET += 1 ));
		LIST_OF_PART_WITH_APTGET[$QTY_OF_PART_WITH_APTGET]="$i"
	else
		APTGET_TYP_OF_PART[$i]="no-aptget"
	fi
	if [[ "${CURRENTSESSIONPARTITION}" = "${LISTOFPARTITIONS[$i]}" ]] && [[ "$(uname -m)" = "i686" ]] || [[ ! -d "${BLKIDMNT_POINT[$i]}/lib64" ]] || [[ "$(cat /proc/cpuinfo | grep "flags" | head -n1 | grep "lm" | wc -l)" = "0" ]];then
		ARCH_OF_PART[$i]="32"
		(( QTY_OF_32BITS_PART += 1 ))
	else
		ARCH_OF_PART[$i]="64"
		(( QTY_OF_64BITS_PART += 1 ))
	fi
	if [[ ! -f "${BLKIDMNT_POINT[$i]}/boot/grub/grub.cfg" ]] || [[ -f "${BLKIDMNT_POINT[$i]}/boot/grub/menu.lst" ]];then
		BOOTPRESENCE_OF_PART[$i]="no boot" # REINSTALL_POSSIBLE will be Yes only if a separate boot exists
	else # REINSTALL_POSSIBLE will be Yes
		BOOTPRESENCE_OF_PART[$i]="with boot"
		if [[ -f "${BLKIDMNT_POINT[$i]}/etc/fstab" ]];then
			temp="$(cat "${BLKIDMNT_POINT[$i]}/etc/fstab" | grep "/boot" )"
			if [[ "$temp" ]] && [[ ! "$(grep "/boot/" <<< "$temp" )" ]];then
				BOOTPRESENCE_OF_PART[$i]="maybe separate"
			fi
		fi
		if [[ "${LISTOFPARTITIONS[$i]}" = "$CURRENTSESSIONPARTITION" ]];then
			if [[ "$(grub-install -v | grep "0.97")" ]]; then
				BOOTPRESENCE_OF_PART[$i]="no boot"
			fi
		else
			for w in dev dev/pts proc sys; do mount -B /$w "${BLKIDMNT_POINT[$i]}/$w"; done
			if [[ "$(chroot "${BLKIDMNT_POINT[$i]}" grub-install -v | grep "0.97")" ]]; then
				BOOTPRESENCE_OF_PART[$i]="no boot"
			fi
			for w in dev/pts dev proc sys; do umount "${BLKIDMNT_POINT[$i]}/$w"; done
		fi
	fi
	if [[ -f "${BLKIDMNT_POINT[$i]}/etc/fstab" ]];then
		if [[ "$(cat "${BLKIDMNT_POINT[$i]}/etc/fstab" | grep "/boot/efi" )" ]];then
			EFI_IN_FSTAB_OF_PART[$i]="fstab-efi"
			a="$(cat "${BLKIDMNT_POINT[$i]}/etc/fstab" | grep "/boot/efi" )"; b="${a%%/*}"; 
			UUID_OF_EFIPART="${b##*=}"
			for ((uuidp=1;uuidp<=NBOFPARTITIONS;uuidp++)); do
				if [[ "${PART_UUID[$uuidp]}" = "$UUID_OF_EFIPART" ]];then
					EFI_OF_PART[$i]="$uuidp"
				fi
			done
			echo "EFI_OF_PART[$i] ${EFI_OF_PART[$i]} ($UUID_OF_EFIPART)"
		else
			EFI_IN_FSTAB_OF_PART[$i]="fstab-without-efi"
		fi
	else
		EFI_IN_FSTAB_OF_PART[$i]="no-fstab"
	fi
done
}

check_separate_boot_partitions()
{
QTY_BOOTPART=0
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	PART_WITH_SEPARATEBOOT[$i]="not-sepboot"
	if [[ "${PART_WITH_OS[$i]}" = "no-os" ]];then
		PART_WITH_SEPARATEBOOT[$i]="is-maybe-sepboot"
		if [[ -f "${BLKIDMNT_POINT[$i]}/grub/grub.cfg" ]] || [[ -f "${BLKIDMNT_POINT[$i]}/grub/menu.lst" ]];then
			#echo "${LISTOFPARTITIONS[$i]} contains a /grub folder, so it is probably a /boot partition."
			#ls "${BLKIDMNT_POINT[$i]}/grub"; #Debug
			(( QTY_BOOTPART += 1 ))
			PART_WITH_SEPARATEBOOT[$i]="is-sepboot"
		fi
	fi
done
}

check_gpt()
{
FDISKL="$(LANGUAGE=C LC_ALL=C sudo fdisk -lu)"
QTY_GPTPART=0
echo "FDISK $FDISKL"
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	GPTTYPE[$i]="no-gpt"
done
while read line; do
	echo "$line"
	if [[ "$(grep -i "GPT" <<< $line )" ]];then
		temp=${line%% *}; part=${temp#*dev/}
		(( QTY_GPTPART += 1 ))
		determine_partnb $part
		LIST_GPTPART[$QTY_GPTPART]="$PARTNB"
		GPTTYPE[$PARTNB]="gpt"
		echo "LIST_GPTPART[$QTY_GPTPART] is $PARTNB ($part , $disk)"
	fi
done < <(echo "$FDISKL")
}

check_64bits_and_show_mainwindow()
{
if [[ "$APPNAME" != "boot-repair" ]];then
	if [[ "$REINSTALL_POSSIBLE" = "yes" ]] && [[ "${ARCH_OF_PART[$PART_TO_REINSTALL_GRUB]}" != "32" ]] && [[ "$(uname -m)" != "x86_64" ]];then
		zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session"; unmount_all_partitions_and_quit_glade
	elif [[ "$PURGE_POSSIBLE" = "yes" ]] && [[ "${ARCH_OF_PART[$PART_TO_REINSTALL_GRUB_PURGE]}" != "32" ]] && [[ "$(uname -m)" != "x86_64" ]];then
		zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session"; unmount_all_partitions_and_quit_glade
	elif [[ "$LIVESESSION" != "yes" ]] && [[ "$REINSTALL_POSSIBLE" = "yes" ]] && [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" != "$CURRENTSESSIONPARTITION" ]];then
		zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session"; unmount_all_partitions_and_quit_glade
	elif [[ "$LIVESESSION" != "yes" ]] && [[ "$PURGE_POSSIBLE" = "yes" ]] && [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]}" != "$CURRENTSESSIONPARTITION" ]];then
		zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session"; unmount_all_partitions_and_quit_glade
	else
		echo 'SET@_mainwindow.show()'
	fi
else
	echo 'SET@_mainwindow.show()'
fi
}

debug_echo_important_variables()
{
if [[ "$APPNAME" = "boot-repair" ]];then
	echo "FSCK_ACTION $FSCK_ACTION PASTEBIN_ACTION $PASTEBIN_ACTION "
else
	echo "FORMAT_OS $FORMAT_OS ($FORMAT_TYPE) WUBI_TO_DELETE $WUBI_TO_DELETE ADVISE_BOOTLOADER_UPDATE $ADVISE_BOOTLOADER_UPDATE"
fi
echo "MBR_ACTION $MBR_ACTION REINSTALL_POSSIBLE $REINSTALL_POSSIBLE PURGE_POSSIBLE $PURGE_POSSIBLE UNHIDEBOOT_ACTION $UNHIDEBOOT_ACTION (${UNHIDEBOOT_TIME}.s) PART_TO_REINSTALL_GRUB $PART_TO_REINSTALL_GRUB (${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}) PART_TO_REINSTALL_GRUB_PURGE $PART_TO_REINSTALL_GRUB_PURGE (${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]}) FORCE_GRUB $FORCE_GRUB NOFORCE_DISK $NOFORCE_DISK REMOVABLEDISK $REMOVABLEDISK UNCOMMENT_GFXMODE $UNCOMMENT_GFXMODE ATA $ATA ADD_KERNEL_OPTION $ADD_KERNEL_OPTION ($CHOSEN_KERNEL_OPTION) MBR_TO_RESTORE $MBR_TO_RESTORE ($DISK_TO_RESTORE_MBR) USE_SEPARATEBOOTPART $USE_SEPARATEBOOTPART (${LISTOFPARTITIONS[$BOOTPART_TO_USE]}) $GRUBPACKAGE (${LISTOFPARTITIONS[$EFIPART_TO_USE]})"
}

######################################### LOOP OF THE GLADE2SCRIPT INTERFACE ###############################
# inputs : user interactions
# outputs : the Glade interface managed by the Bash script
# used by : boot-repair and os-uninstaller
loop_of_the_glade2script_interface()
{
while read ligne
do
	if [[ ${ligne} =~ GET@ ]]
	then
		eval ${ligne#*@}
		echo "DEBUG => in boucle bash :" ${ligne#*@}
	else
		echo "DEBUG=> in bash NOT GET" ${ligne}
		${ligne}
	fi 
done < <(while true
do
	read entree < ${FIFO}
	[[ ${entree} == QuitNow ]] && break
	echo ${entree} 
done)
exit
}

######################################### G2S COMMON ###############################

beginning_of_pulsate()
{
echo 'SET@pulsatewindow.show()'; while true; do echo 'SET@_progressbar1.pulse()'; sleep 0.15; done &
pid_pulse=$!
}

end_of_pulsate()
{
kill ${pid_pulse}; echo 'SET@pulsatewindow.hide()'
}

_mainwindow()
{
unmount_all_partitions_and_quit_glade
}

unmount_all_partitions_and_quit_glade()
{
choice=exit
echo 'SET@_mainwindow.hide()'
zenity --info --timeout=4 --title="$(eval_gettext "$CLEANNAME")" --text="${Operation_aborted}. $No_change_have_been_performed_on_your_computer_See_you_soon" | (echo "Operation_aborted"; save_log_on_disks ; unmount_all_blkid_partitions_except_df)
echo 'EXIT@@'
}

resizemainwindow()
{
sleep 0.1; echo 'SET@_mainwindow.resize(10,10)'
}

_expander1()
{
RETOUREXP=${@}
if [[ "$APPNAME" = "boot-repair" ]];then
	if [[ ${RETOUREXP} = True ]]; then
		echo 'SET@_button_mainapply.hide()'  #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		echo 'SET@_hbox_bootrepairmenu.show()'
		MAIN_MENU="customrepair"; echo "MAIN_MENU becomes : $MAIN_MENU"
		set_easy_repair
	else
		echo 'SET@_hbox_bootrepairmenu.hide()'
		echo 'SET@_button_mainapply.show()'
	fi
fi
resizemainwindow
}

_spinbutton_unhide_boot_menu()
{
UNHIDEBOOT_TIME="${@}"; UNHIDEBOOT_TIME="${UNHIDEBOOT_TIME%*.0}"; echo "UNHIDEBOOT_TIME becomes : $UNHIDEBOOT_TIME"
}

_checkbutton_separateboot()
{
RETOURSEPBUT=${@}
if [[ ${RETOURSEPBUT} = True ]]; then
	USE_SEPARATEBOOTPART="yes"; echo 'SET@_combobox_separateboot.set_sensitive(True)'
else
	USE_SEPARATEBOOTPART="no"; echo 'SET@_combobox_separateboot.set_sensitive(False)'
fi
echo "USE_SEPARATEBOOTPART becomes : $USE_SEPARATEBOOTPART"
}

_checkbutton_efi()
{
RETOUREFI=${@}
if [[ ${RETOUREFI} = True ]]; then
	GRUBPACKAGE="grub-efi"; echo 'SET@_combobox_efi.set_sensitive(True)'
else
	GRUBPACKAGE="grub-pc"; echo 'SET@_combobox_efi.set_sensitive(False)'
fi
echo "GRUBPACKAGE becomes : $GRUBPACKAGE"
}

_checkbutton_unhide_boot_menu()
{
RETOURUNHID=${@}
if [[ ${RETOURUNHID} = True ]]; then
	UNHIDEBOOT_ACTION="yes"; echo 'SET@_spinbutton_unhide_boot_menu.set_sensitive(True)'
else
	UNHIDEBOOT_ACTION="no"; echo 'SET@_spinbutton_unhide_boot_menu.set_sensitive(False)'
fi
echo "UNHIDEBOOT_ACTION becomes : $UNHIDEBOOT_ACTION"
}

_checkbutton_blankextraspace()
{
BLANKEXTRA_RETURN=${@}
if [[ ${BLANKEXTRA_RETURN} = True ]]; then
	zenity --warning --title="$(eval_gettext "$CLEANNAME")" --text="$Warning_blankextra"
	BLANKEXTRA_ACTION="yes"
else
	BLANKEXTRA_ACTION="no"
fi
echo "BLANKEXTRA_ACTION becomes : $BLANKEXTRA_ACTION"
}

_checkbutton_uncomment_gfxmode()
{
RETOURUNCOMMENT=${@}
if [[ ${RETOURUNCOMMENT} = True ]]; then UNCOMMENT_GFXMODE="yes"; else UNCOMMENT_GFXMODE="no";fi
echo "UNCOMMENT_GFXMODE becomes : $UNCOMMENT_GFXMODE"
}

_checkbutton_ata()
{
RETOURATA=${@}
if [[ ${RETOURATA} = True ]]; then ATA="ata"; else ATA="no-ata";fi
echo "ATA becomes : $ATA"
}

_checkbutton_add_kernel_option()
{
RETOURADDKER=${@}
if [[ ${RETOURADDKER} = True ]]; then
	ADD_KERNEL_OPTION="yes"; echo 'SET@_combobox_add_kernel_option.set_sensitive(True)';
else 
	ADD_KERNEL_OPTION="no"; echo 'SET@_combobox_add_kernel_option.set_sensitive(False)';
fi
echo "ADD_KERNEL_OPTION becomes : $ADD_KERNEL_OPTION"
}

_combobox_add_kernel_option()
{
CHOSEN_KERNEL_OPTION="${@}"; echo "CHOSEN_KERNEL_OPTION becomes : $CHOSEN_KERNEL_OPTION"
}

##################### Combo fillin functions###################
common_labels_fillin()
{
echo "SET@_mainwindow.set_title('''$(eval_gettext "$CLEANNAME")''')"
echo "SET@_mainwindow.set_icon_from_file('''$APPNAME.png''')"
echo "SET@_label_advanced_options.set_text('''${Advanced_options}''')"
echo "SET@_tab_main_options.set_text('''${Main_options}''')"
echo "SET@_tab_grub_location.set_text('''${GRUB_location}''')"
echo "SET@_tab_grub_options.set_text('''${GRUB_options}''')"
echo "SET@_tab_mbr_options.set_text('''${MBR_options}''')"
echo "SET@_tab_other_options.set_text('''${Other_options}''')"
echo "SET@_label_unhide_boot_menu.set_text('''${Unhide_boot_menu} :''')"; UNHIDEBOOT_TIME="10"
echo "SET@_label_seconds.set_text('''${seconds}''')"
echo "SET@_label_reinstall_grub.set_text('''${Reinstall_GRUB}''')"
echo "SET@_label_restore_mbr.set_text('''${Restore_MBR}''')"
combobox_restore_mbrof_fillin #Restore MBR
echo "SET@_label_ostoboot_bydefault.set_text('''${OS_to_boot_by_default}''')"
combobox_ostoboot_bydefault_fillin
#combobox_separateboot_fillin #Necessary ??????????!!!!!!!!!!!!!
BUG="FlexNet"; update_translations
echo "SET@_label_blankextraspace.set_text('''${Blank_extra_space} (${solves_BUG})''')"
echo "SET@_label_uncomment_gfxmode.set_text('''${Uncomment_GRUB_GFXMODE}''')"
BUG="out-of-disk"; update_translations
echo "SET@_label_ata.set_text('''${Ata_disk} (${solves_BUG})''')"
echo "SET@_label_add_kernel_option.set_text('''${Add_a_kernel_option}''')"
while read fichier; do echo "SET@_combobox_add_kernel_option.append_text('''${fichier}''')";done < <( echo "acpi=off"; echo "acpi_osi="; echo "edd=on"; echo "i815modeset=1"; echo "i915modeset=0"; echo "i915.modeset=0 xforcevesa"; echo "noapic"; echo "nodmraid"; echo "nolapic"; echo "nomodeset"; echo "nomodeset radeon mode=0"; echo "nomodeset radeon mode=1"; echo "rootdelay=90"; echo "vga=771"; echo "xforcevesa" )
echo 'SET@_combobox_add_kernel_option.set_active(0)'; CHOSEN_KERNEL_OPTION="acpi=off"
echo "SET@_label_open_etc_default_grub.set_text('''${Edit_GRUB_configuration_file}''')"
echo "SET@_label_partition_booted_bymbr.set_text('''${Partition_booted_by_the_MBR}''')"
fill_combobox_partition_booted_bymbr
echo "SET@_about.set_title('''About $CLEANNAME''')"
echo "SET@_about.set_icon_from_file('''$APPNAME.png''')"
echo "SET@_label_translate.set_text('''${Translate}''')"
echo "SET@_label_thanks.set_text('''${Thanks}''')"
echo "SET@_label_gpl.set_markup('''<small>GNU-GPL v3</small>''')"
echo "SET@_label_copyright.set_markup('''<small>(C) 2010-2011 YannUbuntu</small>''')"
echo "SET@_backupwindow.set_title('''$(eval_gettext "$CLEANNAME")''')"
echo "SET@_label_pleasechoosebackuprep.set_text('''${Please_choose_folder_to_put_backup}\\n${USB_disk_recommended}''')"
echo "SET@_label_backup_table.set_text('''${Backup_table}''')"
echo "SET@_label_stats.set_text('''${Participate_stats}''')"
}

combobox_restore_mbrof_fillin()
{
#echo "combobox_restore_mbrof_fillin"
echo "SET@_label_restore_mbrof.set_text('''${Restore_the_MBR_of}''')"
while read fichier; do echo "SET@_combobox_restore_mbrof.append_text('''${fichier}''')";done < <( for ((icrmf=1;icrmf<=NB_MBR_CAN_BE_RESTORED;icrmf++)); do
	echo "${MBR_CAN_BE_RESTORED[$icrmf]}";
done)
echo 'SET@_combobox_restore_mbrof.set_active(0)'; MBR_TO_RESTORE="${MBR_CAN_BE_RESTORED[1]}"
}

combobox_efi_fillin()
{
# Input : INPUTSEPBOOTPART (PART_TO_REINSTALL_GRUB or PART_TO_REINSTALL_GRUB_PURGE)
echo "combobox_efi_fillin ${LISTOFPARTITIONS[$INPUTSEPBOOTPART]}"
echo "SET@_label_efi.set_text('''${EFI_partition}''')"
QTY_EFIPART=0
if [[ "${EFI_IN_FSTAB_OF_PART[$INPUTSEPBOOTPART]}" = "fstab-efi" ]] && [[ "${EFI_OF_PART[$INPUTSEPBOOTPART]}" ]];then
	(( QTY_EFIPART += 1 ))
	LIST_EFIPART[$QTY_EFIPART]="${EFI_OF_PART[$INPUTSEPBOOTPART]}"
fi
for ((icef=1;icef<=QTY_GPTPART;icef++)); do
	if [[ "${DISK_PART[${LIST_GPTPART[$icef]}]}" = "${DISK_PART[$INPUTSEPBOOTPART]}" ]] && [[ "${LIST_GPTPART[$icef]}" != "${EFI_OF_PART[$INPUTSEPBOOTPART]}" ]];then
		(( QTY_EFIPART += 1 ))
		LIST_EFIPART[$QTY_EFIPART]="${LIST_GPTPART[$icef]}"
	fi
done
for ((icef=1;icef<=QTY_GPTPART;icef++)); do
	if [[ "${DISK_PART[${LIST_GPTPART[$icef]}]}" != "${DISK_PART[$INPUTSEPBOOTPART]}" ]] && [[ "${LIST_GPTPART[$icef]}" != "${EFI_OF_PART[$INPUTSEPBOOTPART]}" ]];then
		(( QTY_EFIPART += 1 ))
		LIST_EFIPART[$QTY_EFIPART]="${LIST_GPTPART[$icef]}"
	fi
done
echo "COMBO@@CLEAR@@_combobox_efi"
while read fichier; do echo "SET@_combobox_efi.append_text('''${fichier}''')";done < <( for ((icef=1;icef<=QTY_EFIPART;icef++)); do
	echo "${LISTOFPARTITIONS[${LIST_EFIPART[$icef]}]}"
done)
echo 'SET@_combobox_efi.set_active(0)'; EFIPART_TO_USE="${LIST_EFIPART[1]}"
}

separate_bootpart_show_hide()
{
# Input : PART_TO_REINSTALL_GRUB or PART_TO_REINSTALL_GRUB_PURGE
INPUTSEPBOOTPART="$1"

combobox_separateboot_fillin

echo "separate_bootpart and efi show_hide ${LISTOFPARTITIONS[$INPUTSEPBOOTPART]}" # mapper debug
if [[ "$QTY_PARTWITHOUTOS" = "0" ]];then
	USE_SEPARATEBOOTPART="no"
	echo 'SET@_vbox_separateboot.hide()'
	if [[ "$MBR_ACTION" = "reinstall" ]] && [[ "${BOOTPRESENCE_OF_PART[$INPUTSEPBOOTPART]}" = "no boot" ]];then
		zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="Error : please choose the [Purge GRUB] option and report this bug to the developper of this software."
	fi
else
	echo 'SET@_vbox_separateboot.show()'
	if [[ "$MBR_ACTION" = "reinstall" ]] && [[ "${BOOTPRESENCE_OF_PART[$INPUTSEPBOOTPART]}" = "no boot" ]];then
		USE_SEPARATEBOOTPART="yes"
		echo 'SET@_checkbutton_separateboot.set_active(True)'
	else
		USE_SEPARATEBOOTPART="no"
		echo 'SET@_checkbutton_separateboot.set_active(False)'
		if [[ "${BOOTPRESENCE_OF_PART[$INPUTSEPBOOTPART]}" != "with boot" ]] && [[ "$QTY_BOOTPART" != "0" ]];then
			zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="Please use the Advanced options if you want to use a separate /boot partition."
		fi
	fi
fi

echo "efi_show_hide $INPUTSEPBOOTPART (${GPTTYPE[$INPUTSEPBOOTPART]})" # mapper debug
if [[ "${GPTTYPE[$INPUTSEPBOOTPART]}" = "gpt" ]] && [[ "${EFI_IN_FSTAB_OF_PART[$INPUTSEPBOOTPART]}" = "fstab-efi" ]];then
	echo 'SET@_vbox_efi.show()'
	combobox_efi_fillin
	GRUBPACKAGE="grub-efi"
	echo 'SET@_checkbutton_efi.set_active(True)'
elif [[ "$(grep -i "GPT" <<< "$FDISKL" )" ]] || [[ "${EFI_IN_FSTAB_OF_PART[$INPUTSEPBOOTPART]}" = "fstab-efi" ]];then
	echo 'SET@_vbox_efi.show()'
	combobox_efi_fillin
	GRUBPACKAGE="grub-pc"
	echo 'SET@_checkbutton_efi.set_active(False)'
else
	echo 'SET@_vbox_efi.hide()'
	GRUBPACKAGE="grub-pc"
fi
}

combobox_separateboot_fillin()
{
echo "combobox_separateboot_fillin"
echo "COMBO@@CLEAR@@_combobox_separateboot"
#In priority sep boot located on the same disk
QTY_PARTWITHOUTOS=0
for typecsbf in "is-sepboot" "is-maybe-sepboot";do
	for ((csbf=1;csbf<=NBOFPARTITIONS;csbf++)); do
		if [[ "${PART_WITH_SEPARATEBOOT[$csbf]}" = "$typecsbf" ]] && [[ "${DISK_PART[$INPUTSEPBOOTPART]}" = "${DISK_PART[$csbf]}" ]];then
			(( QTY_PARTWITHOUTOS += 1 ))
			LIST_PARTWITHOUTOS[$QTY_PARTWITHOUTOS]="$csbf"
		fi
	done
	for ((csbf=1;csbf<=NBOFPARTITIONS;csbf++)); do
		if [[ "${PART_WITH_SEPARATEBOOT[$csbf]}" = "$typecsbf" ]] && [[ "${DISK_PART[$INPUTSEPBOOTPART]}" != "${DISK_PART[$csbf]}" ]];then
			(( QTY_PARTWITHOUTOS += 1 ))
			LIST_PARTWITHOUTOS[$QTY_PARTWITHOUTOS]="$csbf"
		fi
	done
done
echo "SET@_label_separateboot.set_text('''${Separate_boot_partition}''')"
while read fichier; do echo "SET@_combobox_separateboot.append_text('''${fichier}''')";done < <( for ((icsf=1;icsf<=QTY_PARTWITHOUTOS;icsf++)); do
	echo "${LISTOFPARTITIONS[${LIST_PARTWITHOUTOS[$icsf]}]}"
done)
echo 'SET@_combobox_separateboot.set_active(0)'; BOOTPART_TO_USE="${LIST_PARTWITHOUTOS[1]}"
}

combobox_ostoboot_bydefault_fillin()
{
echo "combobox_ostoboot_bydefault_fillin"
REINSTALL_POSSIBLE="no"
if [[ "$QTY_OF_PART_WITH_GRUB" != "0" ]];then
	#echo "Order Linux according to their arch type"
	QTY_OF_PART_FOR_REINSTAL=0
	if [[ "$(uname -m)" != "x86_64" ]];then
		loop_ostoboot_bydefault_fillin 64
		loop_ostoboot_bydefault_fillin 32
	else
		loop_ostoboot_bydefault_fillin noorder
	fi
	for ((i=1;i<=QTY_OF_PART_FOR_REINSTAL;i++)); do
		LABEL_PART_FOR_REINSTAL[$i]="${LISTOFPARTITIONS[${LIST_OF_PART_FOR_REINSTAL[$i]}]}"
		for ((j=1;j<=TOTAL_QUANTITY_OF_OS;j++)); do  
			if [[ "${OS_PARTITION[$j]}" = "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_REINSTAL[$i]}]}" ]]; then
				LABEL_PART_FOR_REINSTAL[$i]="${OS_PARTITION[$j]} \(${OS_NAME[$j]}\)"
			fi
		done
		#echo "LABEL_PART_FOR_REINSTAL[$i] ${LABEL_PART_FOR_REINSTAL[$i]}" #debug
	done
	while read fichier; do echo "SET@_combobox_ostoboot_bydefault.append_text('''${fichier}''')";done < <( for ((i=1;i<=QTY_OF_PART_FOR_REINSTAL;i++)); do
		echo "${LABEL_PART_FOR_REINSTAL[$i]}"
	done)
fi
if [[ "$REINSTALL_POSSIBLE" = "yes" ]];then
	echo 'SET@_hbox_ostoboot_bydefault.set_sensitive(True)'
	echo 'SET@_combobox_ostoboot_bydefault.set_active(0)'
	PART_TO_REINSTALL_GRUB="${LIST_OF_PART_FOR_REINSTAL[1]}"
	INPUTSEPBOOTPART="$PART_TO_REINSTALL_GRUB"
	combobox_efi_fillin	#Hide/show efi boot

	###### Combo_place_grub fillin (Place into) ######
	echo "SET@_label_place_grub.set_text('''${Place_GRUB_into}''')"
	fill_combobox_place_grub

	###### Combo_place_alldisks fillin (Place GRUB in all MBR) ####
	REMOVABLEDISK="no"; SHOW_REMOVABLEDISK="no"
	if [[ "$NBOFDISKS" != "1" ]];then
		echo "SET@_label_place_alldisks.set_text('''${Place_GRUB_in_all_disks} (${except_USB_disks_without_OS})''')"
		echo 'SET@_radiobutton_place_alldisks.show()'
		for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
			if [[ "${OS_DISK[$i]}" != "${DISK_PART[$PART_TO_REINSTALL_GRUB]}" ]] && [[ "$SHOW_REMOVABLEDISK" = "no" ]];then
				#It exists another disk with OS
				echo 'SET@_vbox_is_removable_disk.show()'
				echo "SET@_label_is_removable_disk.set_text('''${DISK_PART[$PART_TO_REINSTALL_GRUB]} ${is_a_removable_disk}''')"
				SHOW_REMOVABLEDISK="yes" #To finish the loop
			fi
		done
	else
		echo 'SET@_radiobutton_place_alldisks.hide()'
	fi

	# Combo_force_grub fillin (Force GRUB into) #########
	FORCE_PARTITION="${LISTOFPARTITIONS[${PART_TO_REINSTALL_GRUB}]}"
	echo "SET@_label_force_grub.set_text('''${Force_GRUB_into} ${FORCE_PARTITION} (${for_chainloader})''')"
else
	echo 'SET@_hbox_ostoboot_bydefault.set_sensitive(False)'
fi
}

loop_ostoboot_bydefault_fillin()
{
if [[ "$LIVESESSION" != "yes" ]];then
	for ((ilobf=1;ilobf<=QTY_OF_PART_WITH_GRUB;ilobf++)); do
		if [[ "$QTY_BOOTPART" != "0" ]] || [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "no boot" ]] && [[ "${LISTOFPARTITIONS[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$OS_TO_DELETE_PARTITION" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" ]];then
			(( QTY_OF_PART_FOR_REINSTAL += 1 ))
			LIST_OF_PART_FOR_REINSTAL[$QTY_OF_PART_FOR_REINSTAL]="${LIST_OF_PART_WITH_GRUB[$ilobf]}"
			REINSTALL_POSSIBLE="yes"		
		fi
	done
else
	echo "Order Linux according to their /boot type $1"
	for ((ilobf=1;ilobf<=QTY_OF_PART_WITH_GRUB;ilobf++)); do
		if [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" = "with boot" ]] && [[ "${LISTOFPARTITIONS[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$OS_TO_DELETE_PARTITION" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" ]];then
			(( QTY_OF_PART_FOR_REINSTAL += 1 ))
			LIST_OF_PART_FOR_REINSTAL[$QTY_OF_PART_FOR_REINSTAL]="${LIST_OF_PART_WITH_GRUB[$ilobf]}"
			REINSTALL_POSSIBLE="yes"		
		fi
	done
	for ((ilobf=1;ilobf<=QTY_OF_PART_WITH_GRUB;ilobf++)); do
		if [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" = "maybe separate" ]] && [[ "${LISTOFPARTITIONS[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$OS_TO_DELETE_PARTITION" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" ]] && [[ "$QTY_PARTWITHOUTOS" != "0" ]];then
			(( QTY_OF_PART_FOR_REINSTAL += 1 ))
			LIST_OF_PART_FOR_REINSTAL[$QTY_OF_PART_FOR_REINSTAL]="${LIST_OF_PART_WITH_GRUB[$ilobf]}"
			REINSTALL_POSSIBLE="yes"		
		fi
	done
	for ((ilobf=1;ilobf<=QTY_OF_PART_WITH_GRUB;ilobf++)); do
		if [[ "$QTY_BOOTPART" != "0" ]] && [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" = "no boot" ]] && [[ "${LISTOFPARTITIONS[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$OS_TO_DELETE_PARTITION" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_GRUB[$ilobf]}]}" ]];then
			(( QTY_OF_PART_FOR_REINSTAL += 1 ))
			LIST_OF_PART_FOR_REINSTAL[$QTY_OF_PART_FOR_REINSTAL]="${LIST_OF_PART_WITH_GRUB[$ilobf]}"
			REINSTALL_POSSIBLE="yes"
		fi
	done
fi
}


loop_purge_grub_fillin()
{
if [[ "$LIVESESSION" != "yes" ]];then
	for ((lpgf=1;lpgf<=QTY_OF_PART_WITH_APTGET;lpgf++)); do
		if [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" ]];then
			(( QTY_OF_PART_FOR_PURGE += 1 ))
			LIST_OF_PART_FOR_PURGE[$QTY_OF_PART_FOR_PURGE]="${LIST_OF_PART_WITH_APTGET[$lpgf]}"
			PURGE_POSSIBLE="yes"	
		fi
	done
else
	#Order candidate partitions according to their /boot type
	for ((lpgf=1;lpgf<=QTY_OF_PART_WITH_APTGET;lpgf++)); do
		if [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" = "with boot" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" ]];then
			(( QTY_OF_PART_FOR_PURGE += 1 ))
			LIST_OF_PART_FOR_PURGE[$QTY_OF_PART_FOR_PURGE]="${LIST_OF_PART_WITH_APTGET[$lpgf]}"		
			PURGE_POSSIBLE="yes"
		fi
	done
	for ((lpgf=1;lpgf<=QTY_OF_PART_WITH_APTGET;lpgf++)); do
		if [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" = "maybe separate" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" ]];then
			(( QTY_OF_PART_FOR_PURGE += 1 ))
			LIST_OF_PART_FOR_PURGE[$QTY_OF_PART_FOR_PURGE]="${LIST_OF_PART_WITH_APTGET[$lpgf]}"
			PURGE_POSSIBLE="yes"	
		fi
	done
	for ((lpgf=1;lpgf<=QTY_OF_PART_WITH_APTGET;lpgf++)); do
		if [[ "${BOOTPRESENCE_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" = "no boot" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" != "$1" ]] && [[ "${ARCH_OF_PART[${LIST_OF_PART_WITH_APTGET[$lpgf]}]}" ]];then
			(( QTY_OF_PART_FOR_PURGE += 1 ))
			LIST_OF_PART_FOR_PURGE[$QTY_OF_PART_FOR_PURGE]="${LIST_OF_PART_WITH_APTGET[$lpgf]}"
			PURGE_POSSIBLE="yes"
		fi
	done
fi
}


############### Action items ################

_button_mainquit()
{
echo 'SET@_mainwindow.hide()'
echo "************************Before quitting mainwindow"; debug_echo_important_variables
unmount_all_partitions_and_quit_glade
}

_checkbutton_is_removable_disk()
{
RETOURREMOV=${@}
if [[ ${RETOURREMOV} = True ]]; then REMOVABLEDISK="yes"; else REMOVABLEDISK="no";fi
echo "REMOVABLEDISK becomes : $REMOVABLEDISK"
}

_radiobutton_ostoboot_bydefault()
{
RETOUROSTOB=${@}
if [[ ${RETOUROSTOB} = True ]]; then
	set_radiobutton_ostoboot_bydefault
fi
}

set_radiobutton_ostoboot_bydefault()
{
echo "set_radiobutton_ostoboot_bydefault"
echo 'SET@_combobox_ostoboot_bydefault.set_sensitive(True)'
echo 'SET@_combobox_purge_grub.set_sensitive(False)'
MBR_ACTION="reinstall"; echo "MBR_ACTION becomes : $MBR_ACTION (NBOFDISKS is $NBOFDISKS)"
echo 'SET@_checkbutton_ata.show()'
echo 'SET@_vbox_place_or_force.show()'
echo 'SET@_button_open_etc_default_grub.show()';
separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB
if [[ "$NBOFDISKS" != "1" ]] && [[ ! "$(grep "mapper/" <<< "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" )" ]];then #RAID is broken if install GRUB in sdX
	echo 'SET@_radiobutton_place_alldisks.set_active(True)'; set_radiobutton_place_alldisks
else
	echo 'SET@_radiobutton_place_grub.set_active(True)'; set_radiobutton_place_grub
fi
}

_checkbutton_reinstall_grub()
{
RETOURREINST=${@}
if [[ ${RETOURREINST} = True ]]; then
	set_checkbutton_reinstall_grub
else
	show_tab_grub_location off
	show_tab_grub_options off
	if [[ "$MBR_ACTION" != "restore" ]];then
		MBR_ACTION="nombraction"
	fi
	echo "MBR_ACTION becomes: $MBR_ACTION"
fi
}

_checkbutton_restore_mbr()
{
RETOURRESTORM=${@}
if [[ ${RETOURRESTORM} = True ]]; then
	set_checkbutton_restore_mbr
else
	show_tab_mbr_options off
	if [[ "$MBR_ACTION" != "reinstall" ]] && [[ "$MBR_ACTION" != "purge" ]];then
		MBR_ACTION="nombraction"
	fi
	echo "MBR_ACTION becomes: $MBR_ACTION"
fi
}

set_checkbutton_restore_mbr()
{
MBR_ACTION="restore"
echo 'SET@_checkbutton_reinstall_grub.set_active(False)'
show_tab_grub_location off
show_tab_grub_options off
show_tab_mbr_options on
if [[ "$(grep "generic" <<< $MBR_TO_RESTORE )" ]] || [[ "$(grep "mbr" <<< $MBR_TO_RESTORE )" ]];then
	echo 'SET@_vbox_partition_booted_bymbr.show()'
else
	echo 'SET@_vbox_partition_booted_bymbr.hide()'
fi
echo "MBR_ACTION becomes : $MBR_ACTION"
}

set_checkbutton_reinstall_grub()
{
echo "set_checkbutton_reinstall_grub"
show_tab_grub_location on
show_tab_grub_options on
show_tab_mbr_options off
echo 'SET@_checkbutton_restore_mbr.set_active(False)'
BLANKEXTRA_ACTION="no"; echo 'SET@_checkbutton_blankextraspace.set_active(False)'
UNCOMMENT_GFXMODE="no"; echo 'SET@_checkbutton_uncomment_gfxmode.set_active(False)'
ATA="no-ata"; echo 'SET@_checkbutton_ata.set_active(False)'
ADD_KERNEL_OPTION="no"; echo 'SET@_checkbutton_add_kernel_option.set_active(False)'; echo 'SET@_combobox_add_kernel_option.set_sensitive(False)'
if [[ "$REINSTALL_POSSIBLE" = "yes" ]];then
	echo 'SET@_combobox_purge_grub.set_sensitive(False)'
	echo 'SET@_combobox_ostoboot_bydefault.set_sensitive(True)'
	echo 'SET@_button_open_etc_default_grub.show()'
	MBR_ACTION="reinstall"; echo 'SET@_radiobutton_ostoboot_bydefault.set_active(True)'; set_radiobutton_ostoboot_bydefault # necessary?
	separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB
else
	echo 'SET@_combobox_ostoboot_bydefault.set_sensitive(False)'
	echo 'SET@_combobox_purge_grub.set_sensitive(True)'
	echo 'SET@_radiobutton_purge_grub.set_active(True)'
	echo 'SET@_button_open_etc_default_grub.hide()'
	MBR_ACTION="purge"
	separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB_PURGE
fi
if [[ "$NBOFDISKS" != "1" ]];then
	FORCE_GRUB="all"; echo 'SET@_radiobutton_place_alldisks.set_active(True)'
else
	FORCE_GRUB="no"; echo 'SET@_radiobutton_place_grub.set_active(True)'
fi
echo "MBR_ACTION becomes : $MBR_ACTION"
}

_radiobutton_purge_grub()
{
RETOURPURGEG=${@}
if [[ ${RETOURPURGEG} = True ]]; then
	echo 'SET@_button_mainapply.set_sensitive(False)' #To avoid applying before variables are changed
	if [[ "$INTERNET" != "connected" ]];then
		check_internet_connection
	fi
	if [[ "$INTERNET" = "connected" ]];then #Workaround until we check GRUB reinstall on EFI
		echo 'SET@_combobox_purge_grub.set_sensitive(True)'
		echo 'SET@_combobox_ostoboot_bydefault.set_sensitive(False)'
		echo 'SET@_vbox_place_or_force.hide()'
		echo 'SET@_button_open_etc_default_grub.hide()'
		echo 'SET@_checkbutton_ata.hide()'
		MBR_ACTION="purge"; echo "MBR_ACTION becomes : $MBR_ACTION"
		separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB_PURGE
	else
		echo "SET@_label_purge_grub.set_text('''${requires_internet}''')"
		sleep 1
		if [[ "$MBR_ACTION" = "reinstall" ]];then
			echo 'SET@_radiobutton_ostoboot_bydefault.set_active(True)'
		else
			echo 'SET@_checkbutton_restore_mbr.set_active(True)'
		fi
		echo "SET@_label_purge_grub.set_text('''${Purge_and_reinstall_the_grub_of}''')"
	fi
	echo 'SET@_button_mainapply.set_sensitive(True)'
fi
}

_combobox_purge_grub()
{
RETOURCOMBO_purge_grub="${@}"
if [[ "$PURGE_POSSIBLE" = "yes" ]];then
	echo "RETOURCOMBO_purge_grub : ${RETOURCOMBO_purge_grub}"
	for ((i=1;i<=QTY_OF_PART_FOR_PURGE;i++)); do 
		#echo "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_PURGE[$i]}]}
		if [[ "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_PURGE[$i]}]}" = "$RETOURCOMBO_purge_grub" ]] || [[ "$( grep -i "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_PURGE[$i]}]} " <<< "$RETOURCOMBO_purge_grub" )" ]];then
			if [[ "$LIVESESSION" != "yes" ]] && [[ "$i" != "1" ]];then
				zenity --info --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session $This_will_enable_this_feature"
				echo 'SET@_combobox_purge_grub.set_active(0)'
				separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB_PURGE
			elif [[ "${ARCH_OF_PART[${LIST_OF_PART_FOR_PURGE[$i]}]}" != "32" ]] && [[ "$(uname -m)" != "x86_64" ]] && [[ "$i" != "1" ]];then
				zenity --info --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session $This_will_enable_this_feature"
				echo 'SET@_combobox_purge_grub.set_active(0)'
				separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB_PURGE
			else
				PART_TO_REINSTALL_GRUB_PURGE="${LIST_OF_PART_FOR_PURGE[$i]}"
				echo "PART_TO_REINSTALL_GRUB_PURGE becomes $PART_TO_REINSTALL_GRUB_PURGE (${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]})"
			fi
		fi
	done
fi
}

show_tab_grub_location()
{
if [[ "$1" = "on" ]];then
	echo 'SET@_tab_grub_location.set_sensitive(True)'; echo 'SET@_vbox_grub_location.show()'
else
	echo 'SET@_tab_grub_location.set_sensitive(False)'; echo 'SET@_vbox_grub_location.hide()'
fi
}

show_tab_grub_options()
{
if [[ "$1" = "on" ]];then
	echo 'SET@_tab_grub_options.set_sensitive(True)'; echo 'SET@_vbox_grub_options.show()'
else
	echo 'SET@_tab_grub_options.set_sensitive(False)'; echo 'SET@_vbox_grub_options.hide()'
fi
}

show_tab_mbr_options()
{
if [[ "$1" = "on" ]];then
	echo 'SET@_tab_mbr_options.set_sensitive(True)'; echo 'SET@_vbox_mbr_options.show()'
else
	echo 'SET@_tab_mbr_options.set_sensitive(False)'; echo 'SET@_vbox_mbr_options.hide()'
fi
}

_radiobutton_place_alldisks()
{
RETOURPLACEALL=${@}
if [[ ${RETOURPLACEALL} = True ]]; then
  set_radiobutton_place_alldisks
else
  echo 'SET@_vbox_is_removable_disk.hide()'
fi
}

set_radiobutton_place_alldisks()
{
echo "set_radiobutton_place_alldisks"
FORCE_GRUB="all"; echo "FORCE_GRUB becomes : $FORCE_GRUB"
for ((i=1;i<=QTY_OF_PART_WITH_GRUB;i++)); do
	if [[ "${DISK_PART[$PART_TO_REINSTALL_GRUB]}" != "${DISK_PART[${LIST_OF_PART_WITH_GRUB[$i]}]}" ]];then
		echo 'SET@_vbox_is_removable_disk.show()'
	fi
done
}

_radiobutton_place_grub()
{
RETOURPLACEG=${@}
if [[ ${RETOURPLACEG} = True ]]; then
	set_radiobutton_place_grub
else
	echo 'SET@_combobox_place_grub.set_sensitive(False)';
fi
}

set_radiobutton_place_grub()
{
echo "set_radiobutton_place_grub"
echo 'SET@_combobox_place_grub.set_sensitive(True)'; FORCE_GRUB="no"; echo "FORCE_GRUB becomes : $FORCE_GRUB"
}

_radiobutton_force_grub()
{
RETOURFORCEG=${@}
if [[ ${RETOURFORCEG} = True ]]; then
	FORCE_GRUB="yes"; echo "FORCE_GRUB becomes : $FORCE_GRUB"
fi
}

_combobox_separateboot()
{
RETOURCOMBO_separateboot="${@}"; echo "RETOURCOMBO_separateboot (BOOTPART_TO_USE) : $RETOURCOMBO_separateboot"
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ "$RETOURCOMBO_separateboot" = "${LISTOFPARTITIONS[$i]}" ]];then
		BOOTPART_TO_USE="$i"
	fi
done
}

_combobox_efi()
{
RETOURCOMBO_efi="${@}"; echo "RETOURCOMBO_efi (EFIPART_TO_USE) : $RETOURCOMBO_efi"
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ "$RETOURCOMBO_efi" = "${LISTOFPARTITIONS[$i]}" ]];then
		EFIPART_TO_USE="$i"
	fi
done
}

_combobox_partition_booted_bymbr()
{
RETOURCOMBO_partition_booted_bymbr="${@}"; echo "RETOURCOMBO_partition_booted_bymbr (TARGET_PARTITION) : $RETOURCOMBO_partition_booted_bymbr"
TARGET_PARTITION_FOR_MBR="$(cut -c1-4 <<< $RETOURCOMBO_partition_booted_bymbr )"
echo "TARGET_PARTITION_FOR_MBR becomes $TARGET_PARTITION_FOR_MBR"
}

_combobox_ostoboot_bydefault()
{
RETOURCOMBO_ostoboot_bydefault="${@}"
if [[ "$REINSTALL_POSSIBLE" = "yes" ]];then
	echo "RETOURCOMBO_ostoboot_bydefault : ${RETOURCOMBO_ostoboot_bydefault}"
	for ((i=1;i<=QTY_OF_PART_FOR_REINSTAL;i++)); do 
		#echo "${LABEL_PART_FOR_REINSTAL[${LIST_OF_PART_FOR_REINSTAL[$i]}]}"
		if [[ "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_REINSTAL[$i]}]}" = "$RETOURCOMBO_ostoboot_bydefault" ]] || [[ "$(grep -i "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_REINSTAL[$i]}]} " <<< "$RETOURCOMBO_ostoboot_bydefault" )" ]];then
			if [[ "$LIVESESSION" != "yes" ]] && [[ "$i" != "1" ]];then
				zenity --info --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session $This_will_enable_this_feature"
				echo 'SET@_combobox_ostoboot_bydefault.set_active(0)'
			elif [[ "${ARCH_OF_PART[${LIST_OF_PART_FOR_REINSTAL[$i]}]}" = "64" ]] && [[ "$(uname -m)" != "x86_64" ]] && [[ "$i" != "1" ]];then
				zenity --info --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session $This_will_enable_this_feature"
				echo 'SET@_combobox_ostoboot_bydefault.set_active(0)'
			else
				PART_TO_REINSTALL_GRUB="${LIST_OF_PART_FOR_REINSTAL[$i]}"
				FORCE_PARTITION="${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}"
				echo "PART_TO_REINSTALL_GRUB becomes $PART_TO_REINSTALL_GRUB (${FORCE_PARTITION})"
				echo "SET@_label_force_grub.set_text('''${Force_GRUB_into} ${FORCE_PARTITION} (${for_chainloader})''')"
				echo "SET@_label_is_removable_disk.set_text('''${DISK_PART[$PART_TO_REINSTALL_GRUB]} ${is_a_removable_disk}''')"
				fill_combobox_place_grub
				separate_bootpart_show_hide $PART_TO_REINSTALL_GRUB
			fi
		fi
	done
fi
}

_combobox_restore_mbrof()
{
MBR_TO_RESTORE="${@}"; echo "MBR_TO_RESTORE becomes : $MBR_TO_RESTORE"
echo 'SET@_button_mainapply.set_sensitive(False)' #To avoid applying before variables are changed
if [[ "$(grep "generic" <<< $MBR_TO_RESTORE )" ]] && [[ ! -f /sbin/install-mbr ]] && [[ "$MBR_TO_RESTORE" != "${MBR_CAN_BE_RESTORED[1]}" ]];then
	echo 'SET@_mainwindow.hide()'
	check_internet_connection
	if [[ "$INTERNET" = "connected" ]];then
		mbrenable="yes"
		PACKAGELIST="mbr"
		update_translations
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${This_will_install_PACKAGELIST} ${Do_you_want_to_continue}" || mbrenable="no"
		if [[ "$mbrenable" != "no" ]];then
			echo "SET@_label0.set_text('''$(eval_gettext $'Please wait few seconds...')''')"
			beginning_of_pulsate
			temp="$(apt-get -y update)"
			temp2="$(apt-get install -y --force-yes mbr)"
			if [[ ! "$temp" ]] || [[ ! "$temp2" ]];then
				end_of_pulsate
				zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${Please_close_all_your_package_managers} (${Software_Centre}, ${Update_Manager}, Synaptic, ...)."
			else
				if [[ ! -f /sbin/install-mbr ]];then
					activate_all_repositories
					temp="$(apt-get -y update)"
					temp2="$(apt-get install -y --force-yes mbr)"
					restore_original_repositories
				fi
				end_of_pulsate
				if [[ ! -f /sbin/install-mbr ]];then
					zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST}"
				fi
			fi
		fi
	else
		echo "SET@_label_restore_mbrof.set_text('''${No_internet_connection_detected}''')"; sleep 1
		echo "SET@_label_restore_mbrof.set_text('''${Restore_the_MBR_of}''')"
	fi
	if [[ ! -f /sbin/install-mbr ]];then
		MBR_TO_RESTORE="${MBR_CAN_BE_RESTORED[1]}"; echo 'SET@_combobox_restore_mbrof.set_active(0)'
	else		
		fill_combobox_partition_booted_bymbr
	fi
	echo 'SET@_mainwindow.show()'
else
	fill_combobox_partition_booted_bymbr
fi
echo 'SET@_button_mainapply.set_sensitive(True)'
}

activate_all_repositories()
{
echo "Activate all repositories in ${1}/etc/apt/sources.list"
if [[ -f "${1}/etc/apt/sources.list" ]];then
	mv ${1}/etc/apt/sources.list $TMP_FOLDER/sources.list
	while read line; do
		if [[ "$(grep "# deb " <<< $line )" ]] && [[ ! "$(grep "cdrom" <<< $line )" ]];then
			echo "deb${line##*# deb}" >> ${1}/etc/apt/sources.list
		elif [[ "$(grep "#deb " <<< $line )" ]] && [[ ! "$(grep "cdrom" <<< $line )" ]];then
			echo "deb${line##*#deb}" >> ${1}/etc/apt/sources.list
		elif [[ "$(grep "deb cdrom" <<< $line )" ]] && [[ ! "$(grep "# deb cdrom" <<< $line )" ]];then
			echo "# ${line}" >> ${1}/etc/apt/sources.list #debug
		else
			echo "$line" >> ${1}/etc/apt/sources.list
		fi
	done < <(echo "$(< $TMP_FOLDER/sources.list )" )
	if [[ ! "${1}" ]] && [[ "$(lsb_release -is)" = "Ubuntu" ]];then	#For pastebinit
		UV=$(lsb_release -cs)
		for TEMPUV in lucid maverick natty oneiric precise;do
			if [[ "$UV" = "$TEMPUV" ]];then
				echo "deb http://archive.ubuntu.com/ubuntu/ $UV universe" >> /etc/apt/sources.list
			fi
		done
	fi
	cp ${1}/etc/apt/sources.list $TMP_FOLDER/sources.list_after #debug
else
	echo "No ${1}/etc/apt/sources.list file"
fi
}

restore_original_repositories()
{
echo "Restore the original repositories in ${1}/etc/apt/sources.list"
if [[ -f "$TMP_FOLDER/sources.list" ]];then
	cp $TMP_FOLDER/sources.list ${1}/etc/apt/sources.list
fi
}

fill_combobox_partition_booted_bymbr()
{
#echo "fill_combobox_partition_booted_bymbr"
if [[ "$(grep "generic" <<< $MBR_TO_RESTORE )" ]] || [[ "$(grep "mbr" <<< $MBR_TO_RESTORE )" ]];then
	echo 'SET@_vbox_partition_booted_bymbr.show()'
	echo "COMBO@@CLEAR@@_combobox_partition_booted_bymbr"
	DISK_TO_RESTORE_MBR="$(cut -c1-3 <<< $MBR_TO_RESTORE )"
	TARGET_PARTITION_FOR_MBR="none"
	for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do # Display and select in priority partitions with OS detected by os-prober
		for ((k=1;k<=4;k++)); do
			if [[ "${OS_PARTITION[$i]}" = "${DISK_TO_RESTORE_MBR}$k" ]] && [[ "${OS_PARTITION[$i]}" != "$OS_TO_DELETE_PARTITION" ]];then
				while read fichier; do
					echo "SET@_combobox_partition_booted_bymbr.append_text('''${fichier}''')"
				done < <(echo "${DISK_TO_RESTORE_MBR}$k (${OS_NAME[$i]})")
				if [[ "$TARGET_PARTITION_FOR_MBR" = "none" ]];then
					TARGET_PARTITION_FOR_MBR="${DISK_TO_RESTORE_MBR}$k";
				fi
			fi
		done
	done
	for ((k=1;k<=4;k++)); do
		BAD_PART="no"
		for ((j=1;j<=NBOFPARTITIONS;j++)); do
			if [[ "${DISK_TO_RESTORE_MBR}$k" = "${LISTOFPARTITIONS[$j]}" ]];then #Exclude SWAP, EXTENDED part etc...
				for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do #Exlude partitions already listed
					if [[ "${OS_PARTITION[$i]}" = "${DISK_TO_RESTORE_MBR}$k" ]];then BAD_PART="yes"; fi
				done
				if [[ "$BAD_PART" = "no" ]] && [[ "${DISK_TO_RESTORE_MBR}$k" != "$OS_TO_DELETE_PARTITION" ]];then
					#Partitions without OS detected by os-prober
					while read fichier; do
						echo "SET@_combobox_partition_booted_bymbr.append_text('''${fichier}''')";
					done < <(echo "${DISK_TO_RESTORE_MBR}$k")
					if [[ "$TARGET_PARTITION_FOR_MBR" = "none" ]];then
						TARGET_PARTITION_FOR_MBR="${DISK_TO_RESTORE_MBR}$k";
					fi
				fi
			fi
		done
	done
	echo "TARGET_PARTITION_FOR_MBR becomes $TARGET_PARTITION_FOR_MBR"
	echo 'SET@_combobox_partition_booted_bymbr.set_active(0)'
else
	echo 'SET@_vbox_partition_booted_bymbr.hide()'
fi
}

check_available_target_partition_for_generic_mbr()
{
for ((m=1;m<=NBOFDISKS;m++)); do
	TARGET_PARTITION_IS_AVAILABLE[$m]="no"
	for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do # Display and select in priority partitons with OS detected by os-prober
		for ((k=1;k<=4;k++)); do
			if [[ "${OS_PARTITION[$i]}" = "${LISTOFDISKS[$m]}$k" ]] && [[ "${OS_PARTITION[$i]}" != "$OS_TO_DELETE_PARTITION" ]];then
				TARGET_PARTITION_IS_AVAILABLE[$m]="yes"
			fi
		done
	done
	for ((k=1;k<=4;k++)); do
		BAD_PART="no"
		for ((j=1;j<=NBOFPARTITIONS;j++)); do
			if [[ "${LISTOFDISKS[$m]}$k" = "${LISTOFPARTITIONS[$j]}" ]];then #Exclude SWAP, EXTENDED part etc...
				for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do #Exlude partitions already listed
					if [[ "${OS_PARTITION[$i]}" = "${LISTOFDISKS[$m]}$k" ]];then
						BAD_PART="yes"; 
					fi
				done
				if [[ "$BAD_PART" = "no" ]] && [[ "${LISTOFDISKS[$m]}$k" != "$OS_TO_DELETE_PARTITION" ]];then
					#Partitions without OS detected by os-prober
					TARGET_PARTITION_IS_AVAILABLE[$m]="yes"
				fi
			fi
		done
	done
	#echo "TARGET_PARTITION_IS_AVAILABLE[${LISTOFDISKS[$m]}] is : ${TARGET_PARTITION_IS_AVAILABLE[$m]}"
done
}

_combobox_place_grub()
{
NOFORCE_DISK="${@}"; echo "RETOURCOMBO_place_grub (NOFORCE_DISK) : $NOFORCE_DISK"
}

fill_combobox_place_grub()
{
echo "COMBO@@CLEAR@@_combobox_place_grub"
NOFORCE_DISK="${DISK_PART[$PART_TO_REINSTALL_GRUB]}"
while read fichier; do
	echo "SET@_combobox_place_grub.append_text('''${fichier}''')";
done < <( echo "${NOFORCE_DISK}";
for ((i=1;i<=NBOFDISKS;i++)); do
	if [[ "${LISTOFDISKS[$i]}" != "${NOFORCE_DISK}" ]];then #Propose by default the disk of PART_TO_REINSTALL_GRUB
		echo "${LISTOFDISKS[$i]}"
	fi
done)
echo 'SET@_combobox_place_grub.set_active(0)'
}

_combobox_partition_booted_bymbr()
{
RETOURCOMBO_partition_booted_bymbr="${@}"; temp="${RETOURCOMBO_partition_booted_bymbr%% *}"; TARGET_PARTITION_FOR_MBR="${temp##*[a-z]}" #Y of sdXY
echo "RETOURCOMBO_partition_booted_bymbr: $RETOURCOMBO_partition_booted_bymbr , TARGET_PARTITION_FOR_MBR becomes $TARGET_PARTITION_FOR_MBR"
}

_button_thanks()
{
zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="THANKS TO EVERYBODY PARTICIPATING DIRECTLY OR INDIRECTLY TO MAKE THIS SOFTWARE A USEFUL TOOL FOR THE COMMUNITY:\\ntesters, coders, translators, everybody helping people on forums, or sharing their knowledge on forums/wiki...\\nAmong them: Babdu, Hizoka, oldfred, bcbc, AnsuzP, Josepe, mörgæs, Malbo, Meierfra, G.Hulselmans, MAFoElffen, Adrian, YesWeCan, Hakunka-M, GRUB devs, drs305 and many more"
}

_button_translate()
{
xdg-open "https://translations.launchpad.net/boot-repair" &
}

############## Other Options
_button_backup_table()
{
echo 'SET@_mainwindow.hide()'
echo 'SET@_backupwindow.show()'
}

_button_cancelbackup()
{
echo 'SET@_mainwindow.show()'
echo 'SET@_backupwindow.hide()'
}

_backup_filechooserwidget()
{
CHOSENBACKUPREP=${@}
echo "CHOSENBACKUPREP $CHOSENBACKUPREP"
}

_button_savebackup()
{
if [[ ! "$(type zip)" ]];then
	ask_internet_connection
	end_of_pulsate
	if [[ "$INTERNET" = "connected" ]];then
		zipinstall="yes"
		PACKAGELIST="zip"
		update_translations
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${This_will_install_PACKAGELIST} ${Do_you_want_to_continue}" || zipinstall="no"
		if [[ "$zipinstall" != "no" ]];then
			echo "SET@_label0.set_text('''$(eval_gettext $'Please wait few seconds...')''')"
			beginning_of_pulsate
			temp="$(apt-get -y update)"
			temp2="$(apt-get install -y --force-yes $PACKAGELIST)"
			if [[ ! "$temp" ]] || [[ ! "$temp2" ]];then
				end_of_pulsate
				zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${Please_close_all_your_package_managers} (${Software_Centre}, ${Update_Manager}, Synaptic, ...)."
			else
				if [[ ! "$(type zip)" ]];then
					activate_all_repositories
					temp="$(apt-get -y update)"
					temp2="$(apt-get install -y --force-yes $PACKAGELIST)"
					restore_original_repositories
				fi
				end_of_pulsate
				if [[ ! "$(type zip)" ]];then
					zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST}"
				fi
			fi
		fi
	else
		zenity --warning --timeout=3 --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}. ${Please_connect_internet} ${Then_try_again}"
	fi
fi
if [[ "$(type zip)" ]];then
	temp="${CHOSENBACKUPREP}/backup_$DATE$SECOND"
	zip -r $temp /tmp/clean
	zenity --info --text="Partition tables, MBRs and logs have been saved into ${temp}.zip"
	echo 'SET@_mainwindow.show()'
	echo 'SET@_backupwindow.hide()'
fi
}

_checkbutton_stats()
{
RETOURSTATS=${@}
if [[ ${RETOURSTATS} = True ]]; then
	SENDSTATS="sendstats"
else
	SENDSTATS="nostats"
fi
echo "SENDSTATS becomes : $SENDSTATS"
}

