#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## 19/12/2011
## Special thanks to Babdu and BIS devs.

## LIBRAIRIES FOR CLEAN-UBIQUITY, OS-UNINSTALLER AND BOOT REPAIR
## http://ubuntuforums.org/showthread.php?t=1615667


######################################### INITIALIZATION ##################################################
initialization()
{
PACK_NAME="clean"  #Same name for ubiquitybefore, ubiquityafter, uninstaller, bootrepair (if changed, must change file places)
LOG_PATH_LINUX="/var/log/$PACK_NAME/log"
LOG_PATH_OTHER="/$PACK_NAME/log"
MBR_PATH_LINUX="/var/log/$PACK_NAME/mbr_backups"
MBR_PATH_OTHER="/$PACK_NAME/mbr_backups"
NEW_LINUX_PARTITION="nonewlinuxpartition"   ### The partition where Ubiquity has installed Linux (see cleannubiquityafter)
}


######################################### LOG PREPARATION (will be later copied on the disks) ###############################
log_preparation()
{
DATE="$(date +'%Y-%m-%d__%Hh%M')"; SECOND="$(date +'%S')";TMP_FOLDER="/tmp/$PACK_NAME/$DATE$APPNAME$SECOND"; mkdir -p "$TMP_FOLDER"
TMP_FOLDER_TO_BE_CLEARED="/tmp/$PACK_NAME/to_be_cleared"; mkdir -p "$TMP_FOLDER_TO_BE_CLEARED"
TMP_LOG="$TMP_FOLDER/$DATE.$APPNAME.log"
exec >& >(tee "$TMP_LOG.tee")
echo "**************** log of $APPNAME $DATE ****************"
if [[ $(grep "cleanubiquity" <<< $APPNAME ) ]];	then
	temp=$(LANGUAGE=C LC_ALL=C apt-cache policy clean-ubiquity | grep Installed )
else
	temp=$(LANGUAGE=C LC_ALL=C apt-cache policy $APPNAME | grep Installed )
fi
APPNAME_VERSION=${temp#* Installed: }
echo "$APPNAME version : $APPNAME_VERSION"
temp=$(LANGUAGE=C LC_ALL=C apt-cache policy clean | grep Installed ); COMMON_VERSION=${temp#* Installed: }
echo "clean version : $COMMON_VERSION"
}

######################################### delete_tmp_folder_to_be_cleared_and_update_osprober ###############################
delete_tmp_folder_to_be_cleared_and_update_osprober()
{
#echo "Delete the content of TMP_FOLDER_TO_BE_CLEARED and put os-prober in memory"
rm -f $TMP_FOLDER_TO_BE_CLEARED/*
OSPROBER=$(os-prober)
blkid -g			#Update the UUID cache
BLKID=$(blkid)
}

######################################### check_blkid_partitions ###############################
#Used by : before, after, repair, uninstaller
check_blkid_partitions()
{
NBOFPARTITIONS=0; NBOFDISKS=0; LISTOFDISKS[0]=0
#Add current session partition first
if [[ "$LIVESESSION" = "no" ]];then #Not called by cleanubiquity
	loop_check_blkid_partitions "a${CURRENTSESSIONPARTITION}" include #Put currentsession first
fi
#Add standard partitions
loop_check_blkid_partitions exclude "a${CURRENTSESSIONPARTITION}"
#Add LVM partitions
if [[ "$(grep "LVM2_member" <<< $BLKID )" ]];then # http://www.linux-sxs.org/storage/fedora2ubuntu.html
	if [[ "$(type lvscan)" ]];then
		while read lvline; do			#e.g. "ACTIVE  '/dev/VolGroup00/LogVol00' [26.06 GB] inherit"
			echo "LVLINE $lvline"
			if [[ "$(grep "/dev" <<< "$lvline" )" ]];then
				temp=${lvline#*dev/}	#e.g. "VolGroup00/LogVol00' [26.06 GB] inherit"
				part=${b%%\'*}		#e.g. "VolGroup00/LogVol00"
				disk=${c%/*}		#e.g. "VolGroup00"
				add_disk_and_part exclude "a${CURRENTSESSIONPARTITION}"
			fi
		done < <(echo "$LVSCAN")
	fi
fi
}

loop_check_blkid_partitions()
{
while read line; do
	#echo "LOOP$line"
	temp=${line%%:*} 
	part=${temp#*dev/} 		#e.g. "sda12" or "mapper/isw_decghhaeb_Volume0p2" or "/mapper/isw_bcbggbcebj_ARRAY4"
	disk=""
	#echo "part : $part"		#Add "squashfs" ?
	if [[ ! "$(grep "swap" <<< $line )" ]] && [[ ! "$(grep "/dev/loop" <<< $line )" ]] && [[ ! "$(df "/dev/$part" | grep "/cdrom" )" ]];then
		if [[ "$(grep "LVM2_member" <<< $line )" ]];then # http://www.linux-sxs.org/storage/fedora2ubuntu.html
			echo "$part is LVM2_member"
		elif [[ "$(grep "mapper" <<< $part )" ]] && [[ "$(type dmraid)" ]];then
			for raidset in $(dmraid -sa -c); do
				if [[ "$(grep "mapper/$raidset" <<< "$part" )" ]];then
					disk="mapper/$raidset"
					add_disk_and_part $1 $2
				fi
			done
		elif [[ "$(grep "md[0-9]" <<< $part )" ]];then
			#http://www.howtoforge.com/how-to-set-up-software-raid1-on-a-running-system-incl-grub2-configuration-ubuntu-10.04-p2
			#https://wiki.archlinux.org/index.php/Convert_a_single_drive_system_to_RAID
			#http://ubuntuforums.org/showthread.php?t=1551087
			if [[ "$NBOFDISKS" != "0" ]];then
				disk="${LISTOFDISKS[1]}"
			elif [[ "$(grep "/dev/sda" <<< "$BLKID" )" ]];then
				disk="sda"
			else
				disk="error$part"
			fi
			add_disk_and_part $1 $2
		elif [[ ! "$disk" ]];then
			determine_disk_from_part
			add_disk_and_part $1 $2
		fi
	fi
done < <(echo "$BLKID")
}

determine_disk_from_part()
{
if [[ "$(grep "[0-9][a-z][0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%[a-z][0-9]*}) ]];then
	disk="${part%[a-z][0-9]*}"			#e.g. "mapper/isw_decghhaeb_Volume0p1" -> "mapper/isw_decghhaeb_Volume0"
elif [[ "$(grep "[0-9][a-z][a-z][0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%%[a-z][a-z][0-9]*}) ]];then
	disk="${part%%[a-z][a-z][0-9]*}"		#e.g. "mapper/isw_decghhaeb_Volume0pt1" -> "mapper/isw_decghhaeb_Volume0"
elif [[ "$(grep "[0-9][a-z][a-z][a-z][0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%%[a-z][a-z][a-z][0-9]*}) ]];then
	disk="${part%%[a-z][a-z][a-z][0-9]*}"		#e.g. "mapper/isw_decghhaeb_Volume0pts1" -> "mapper/isw_decghhaeb_Volume0"
elif [[ "$(grep "[0-9][a-z][a-z][a-z][a-z][0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%%[a-z][a-z][a-z][a-z][0-9]*}) ]];then
	disk="${part%%[a-z][a-z][a-z][a-z][0-9]*}"	#e.g. "mapper/isw_decghhaeb_Volume0part1" -> "mapper/isw_decghhaeb_Volume0"
elif [[ "$(grep "hd[a-z][0-9]" <<< $part )" ]] || [[ "$(grep "hd[a-z][a-z][0-9]" <<< $part )" ]] || [[ "$(grep "sd[a-z][0-9]" <<< $part )" ]] || [[ "$(grep "sd[a-z][a-z][0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%[0-9]*}) ]];then
	disk="${part%%[0-9]*}"		#e.g. "sda"   ##Add sr[0-9] (memcard)?
elif [[ "$(grep "[0-9]" <<< $part )" ]] && [[ $(ls /dev/${part%%[0-9]*}) ]];then
	disk="${part%%[0-9]*}"		#e.g. "mapper/nvidia_dgicebef12" or "mapper/isw_bcbggbcebj_ARRAY3" (FakeRAID)
	#part="dm-${part##*ARRAY}"	#e.g. "dm-2"
elif [[ "$(grep "-" <<< $part )" ]] && [[ $(ls /dev/${part%-*}) ]];then
	disk="${part%-*}"		#e.g. mapper/svg-ca -> mapper/svg
elif [[ "$(grep "-" <<< $part )" ]] && [[ $(ls /dev/${part%%-*}) ]];then
	disk="${part%%-*}"		#e.g. mapper/svg-ca-1 -> mapper/svg
elif [[ "$(grep "_" <<< $part )" ]] && [[ $(ls /dev/${part%_*}) ]];then
	disk="${part%_*}"		#e.g. mapper/svg_ca -> mapper/svg
elif [[ "$(grep "_" <<< $part )" ]] && [[ $(ls /dev/${part%%_*}) ]];then
	disk="${part%%_*}"		#e.g. mapper/svg_ca_1 -> mapper/svg
elif [[ "$(grep "/" <<< $part )" ]] && [[ $(ls /dev/${part%/*}) ]];then
	disk="${part%/*}"		#e.g. mvg/Vol1 -> mvg (RAID which does not use /mapper/)
elif [[ "$(grep "/" <<< $part )" ]] && [[ $(ls /dev/${part%%/*}) ]];then
	disk="${part%%/*}"		#e.g. mvg/Vol/1 -> mvg
elif [[ ! "$(grep "[0-9]" <<< $part )" ]] && [[ ! "$(grep "-" <<< $part )" ]] && [[ ! "$(grep "/" <<< $part )" ]] && [[ ! "$(grep "_" <<< $part )" ]];then
	disk=""				#e.g. "sda" with ARRAY http://paste.ubuntu.com/671519/
else
	disk="${part%%[0-9]*}"; disk="${part%%-*}"; disk="${part%%_*}"
	echo "${part} has unknown disk type. Guessed disk $disk"
fi
}

add_disk_and_part()
{
if [[ "a${part}" = "$1" ]] || [[ "$1" = "exclude" ]] && [[ "a${part}" != "$2" ]] && [[ "$disk" ]];then
	ADD_DISK="yes"
	for ((b=1;b<=NBOFDISKS;b++)); do
		if [[ "${LISTOFDISKS[$b]}" = "$disk" ]];then
			ADD_DISK=""
		fi
	done
	if [[ "$ADD_DISK" ]];then
		(( NBOFDISKS += 1 ))
		LISTOFDISKS[$NBOFDISKS]="$disk"
		#echo "Disk $NBOFDISKS is ${disk}"
		mkdir -p "$TMP_FOLDER/${disk}"
	fi
	(( NBOFPARTITIONS += 1 ))
	LISTOFPARTITIONS[$NBOFPARTITIONS]="$part"
	DISK_PART[$NBOFPARTITIONS]="${disk}"
	#echo "Partition $NBOFPARTITIONS is ${part} (${disk})"
	mkdir -p "$TMP_FOLDER/${part}"
fi
}

######################################### determine_part_uuid ###############################
# called by : before, after, repair, uninstaller
determine_part_uuid()
{
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	temp="$(echo "$BLKID" | grep "${LISTOFPARTITIONS[$i]}")"; temp=${temp#*UUID=\"}; temp=${temp%%\"*}
	PART_UUID[$i]="$temp"								#e.g. "b3f9b3f2-a0c7-49c1-ae50-f849a02fd52e"
	#echo "PART_UUID of ${LISTOFPARTITIONS[$i]} is ${PART_UUID[$i]}"
done
}

######################################### Check location first partition ###############################
check_location_first_partitions()
{
for ((i=1;i<=NBOFDISKS;i++)); do
	SECTORS_BEFORE_PART[$i]=0; rm -f /tmp/clean_sort
	for partition in $(ls "/sys/block/${LISTOFDISKS[$i]}/" | grep "${LISTOFDISKS[$i]}");do
		echo "$(cat "/sys/block/${LISTOFDISKS[$i]}/${partition}/start" )" >> /tmp/clean_sort
	done
	echo "2048" >> /tmp/clean_sort # Save maximum 2048 sectors (in case the first partition is far)
	a=$(cat "/tmp/clean_sort" | sort -g -r | tail -1 )  #sort the file in the increasing order
	if [[ "$(grep "^[0-9]\+$" <<< $a )" ]];then
		SECTORS_BEFORE_PART[$i]="$a"
	else
		SECTORS_BEFORE_PART[$i]="1" # Save minimum 1 sector (the MBR)
	fi
	rm /tmp/clean_sort
	#  a=$(LANGUAGE=C LC_ALL=C fdisk -lu /dev/$disk | grep "sectors of"); b=${a##*= }; c=${b% *}; echo "$c" > /tmp/clean_sort   #Other way to calculate
	echo "$(stat -c %B /dev/${LISTOFDISKS[$i]})" > /tmp/clean_sort
	echo "512" >> /tmp/clean_sort # Save minimum 512 bytes/sector (in case there is a problem with stat)
	BYTES_PER_SECTOR[$i]=$(cat "/tmp/clean_sort" | sort -g | tail -1 ) 
	rm /tmp/clean_sort
	BYTES_BEFORE_PART[$i]=$((${SECTORS_BEFORE_PART[$i]}*${BYTES_PER_SECTOR[$i]}))
	echo "BYTES_BEFORE_PART[$i] (${LISTOFDISKS[$i]}) = ${SECTORS_BEFORE_PART[$i]} sectors * ${BYTES_PER_SECTOR[$i]} bytes = ${BYTES_BEFORE_PART[$i]} bytes."
done
}

######################################### Mount / Unmount functions ###############################
#Used by : repair, uninstaller, before, after
mount_all_blkid_partitions_except_df()
{
#echo "Mount all blkid partitions except the ones already mounted"
MOUNTB="$(mount)"
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ "$(grep "/dev/${LISTOFPARTITIONS[$i]} on" <<< "$MOUNTB" )" ]];then
		if [[ "${LISTOFPARTITIONS[$i]}" != "$CURRENTSESSIONPARTITION" ]];then
			#echo "DF$(df /dev/${LISTOFPARTITIONS[$i]} | grep "/dev/${LISTOFPARTITIONS[$i]}" )"	#debug
			temp="$(grep "/dev/${LISTOFPARTITIONS[$i]} on" <<< "$MOUNTB" )"
			temp="${temp#*on }"
			BLKIDMNT_POINT[$i]="${temp%% type*}"
		else
			BLKIDMNT_POINT[$i]=""
		fi
	else
		BLKIDMNT_POINT[$i]="/mnt/$PACK_NAME/${LISTOFPARTITIONS[$i]}"
		mkdir -p "${BLKIDMNT_POINT[$i]}"
		mount /dev/${LISTOFPARTITIONS[$i]} "${BLKIDMNT_POINT[$i]}"
	fi
	#echo "BLKID Mount point of ${LISTOFPARTITIONS[$i]} is: ${BLKIDMNT_POINT[$i]}"
	for ((j=1;j<=TOTAL_QUANTITY_OF_OS;j++)); do #Correspondency with OS_PARTITION
		if [[ "${LISTOFPARTITIONS[$i]}" = "${OS_PARTITION[$j]}" ]];then
			MNT_PATH[$j]="${BLKIDMNT_POINT[$i]}"; #echo "Mount path of ${OS_PARTITION[$j]} is: ${MNT_PATH[$j]}"
		fi
	done
done
update_log_and_mbr_path
}


#Used by : repair, uninstaller, before, after
unmount_all_blkid_partitions_except_df()
{
echo "Unmount all blkid partitions except df ones"
pkill pcmanfm	#To avoid it automounts
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	#echo "BLKID Mount point of ${LISTOFPARTITIONS[$i]} is: ${BLKIDMNT_POINT[$i]}"
	if [[ "$(grep "/mnt/$PACK_NAME" <<< "${BLKIDMNT_POINT[$i]}" )" ]];then
		umount "${BLKIDMNT_POINT[$i]}"
	fi
done
}


################################### SAVE / UPDATE THE LOG ON DISKS ##############################################
save_log_on_disks()
{
echo "DF $(df -Th)
FDISK $(fdisk -lu)"
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do  
	if [[ "${OS_PARTITION[$i]}" != "$OS_TO_DELETE_PARTITION" ]]; then
		mkdir -p "${LOG_PATH[$i]}/$DATE$APPNAME$SECOND"  #In case it has been deleted (by virus or else)
		cp -r $TMP_FOLDER/* "${LOG_PATH[$i]}/$DATE$APPNAME$SECOND" ; echo "Logs saved into ${LOG_PATH[$i]}/$DATE$APPNAME$SECOND"
	fi
done
}


########################### CHECKS THE OS NAMES AND PARTITIONS AND TYPES, AND MOUNTS THEM ##################################
# called by : before, after
check_os_and_mount_blkid_partitions()
{
check_blkid_partitions					#In order to save MBR of all disks detected by blkid
remove_stage1_from_other_os_partitions			#Solve a bug of os-prober (allow to detect some OS that would be hidden)
determine_part_uuid					#After check_blkid_partitions
check_location_first_partitions				#Output: $BYTES_BEFORE_PART[$disk]
check_os_names_and_partitions_and_types
mount_all_blkid_partitions_except_df			#To update OS_Mount_points
initialize_log_folders_in_os				#After OS_Mount_points have been updated
put_the_current_mbr_in_tmp
if [[ "$APPNAME" != "cleanubiquityafter" ]];then
	check_disks_containing_mbr_backups
	duplicate_backup_from_tmp_to_os_without_backup
fi
}


########################### CHECKS THE OS NAMES AND PARTITIONS AND TYPES, AND MOUNTS THEM ##################################
# called by : before, after, repair, uninstaller
check_os_names_and_partitions_and_types()
{
echo "OSPROBER: $OSPROBER"
echo "BLKID: $BLKID"
if [[ "$OSPROBER" ]];then
	TOTAL_QUANTITY_OF_OS=0; QUANTITY_OF_DISKS=0
	while read line; do
		(( TOTAL_QUANTITY_OF_OS += 1 ))
		temp=${line##*/dev/}; part=${temp%%:*}; OS_PARTITION[$TOTAL_QUANTITY_OF_OS]=${part}		#e.g. "sda1" or "sdc10"
		determine_disk_from_part
		OS_DISK[$TOTAL_QUANTITY_OF_OS]=${disk}								#e.g. "sda" or "sdc"
		OS_COMPLETE_NAME[$TOTAL_QUANTITY_OF_OS]=${line#*:}						#e.g. "Ubuntu 10.04.1 LTS (10.04):Ubuntu:linux"
		temp=${OS_COMPLETE_NAME[$TOTAL_QUANTITY_OF_OS]%%:*}; OS_NAME[$TOTAL_QUANTITY_OF_OS]=${temp% *}		#e.g. "Ubuntu 10.04.1 LTS"
		OS_MINI_NAME[$TOTAL_QUANTITY_OF_OS]=${OS_NAME[$TOTAL_QUANTITY_OF_OS]%% *}				#e.g. "Ubuntu"
		if [[ "$QUANTITY_OF_DISKS" = 0 ]] || [[ "${OS_DISK[$TOTAL_QUANTITY_OF_OS]}" != "${DISK[$QUANTITY_OF_DISKS]}" ]]; then
			(( QUANTITY_OF_DISKS += 1 ))
			DISK[$QUANTITY_OF_DISKS]=${OS_DISK[$TOTAL_QUANTITY_OF_OS]}		#List of disks with OS  (e.g. "sdb")
		fi
	done < <(echo "$OSPROBER")

	##CHECK THE TYPE OF EACH OS
	QUANTITY_OF_DETECTED_LINUX=0; QUANTITY_OF_DETECTED_WINDOWS=0; QUANTITY_OF_DETECTED_MACOS=0; QUANTITY_OF_UNKNOWN_OS=0
	for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
		if [[ "$(grep -i "linux" <<< ${OS_COMPLETE_NAME[$i]} )" ]]; then 
			(( QUANTITY_OF_DETECTED_LINUX += 1 ))
			TYPE[$i]="linux"
		elif [[ "$(grep -i "Windows" <<< ${OS_COMPLETE_NAME[$i]} )" ]];then
			(( QUANTITY_OF_DETECTED_WINDOWS += 1 ))
			TYPE[$i]="windows"
		elif [[ "$(grep -i "Mac" <<< ${OS_COMPLETE_NAME[$i]} )" ]];then
			(( QUANTITY_OF_DETECTED_MACOS += 1 ))
			TYPE[$i]="macos"
		else
			(( QUANTITY_OF_UNKNOWN_OS += 1 ))
			TYPE[$i]="else"
		fi
		echo "${OS_PARTITION[$i]} contains ${OS_NAME[$i]} (${TYPE[$i]})"
	done
	echo "$QUANTITY_OF_DISKS disks with OS, $TOTAL_QUANTITY_OF_OS OS : $QUANTITY_OF_DETECTED_LINUX Linux, $QUANTITY_OF_DETECTED_MACOS MacOS, $QUANTITY_OF_DETECTED_WINDOWS Windows, $QUANTITY_OF_UNKNOWN_OS unknown type OS."
fi
}


########################### CREATE LOG FOLDERS INSIDE OS ##################################
initialize_log_folders_in_os()
{
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
	mkdir -p "${MBR_PATH[$i]}"
	mkdir -p "${LOG_PATH[$i]}/$DATE$APPNAME$SECOND"
done
}

########################### update_log_and_mbr_path ##################################
update_log_and_mbr_path()
{
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
	if [[ "${TYPE[$i]}" = "linux" ]];then
		LOG_PATH[$i]="${MNT_PATH[$i]}$LOG_PATH_LINUX"	#Folder to store logs
		MBR_PATH[$i]="${MNT_PATH[$i]}$MBR_PATH_LINUX"	#Folder to store the MBR backup that can be restored by Boot-Repair or OS-Uninstaller
	else
		LOG_PATH[$i]="${MNT_PATH[$i]}$LOG_PATH_OTHER"
		MBR_PATH[$i]="${MNT_PATH[$i]}$MBR_PATH_OTHER"
	fi
done
}

######################## DETECTS THE PREVIOUS MBR BACKUPS ##################################################
# called by : before , after, uninstaller , repair
check_disks_containing_mbr_backups()
{
#echo "CREATES A LIST OF DISKS CONTAINING BACKUP"
QTY_OF_DISKS_WITH_BACKUP=0
for ((m=1;m<=QUANTITY_OF_DISKS;m++)); do
	QTY_OF_OS_ON_DISK[$m]=0; NB_OF_BACKUPS_IN_DISK[$m]=0
	#echo "************************** Loop for ${DISK[$m]} **********************"
	for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
		if [[ "${OS_DISK[$i]}" = "${DISK[$m]}" ]];then
			(( QTY_OF_OS_ON_DISK[$m] += 1 ))
			OS_PARTITION_ON_DISK[${QTY_OF_OS_ON_DISK[$m]}]="${OS_PARTITION[$i]}"; TYPE_ON_DISK[${QTY_OF_OS_ON_DISK[$m]}]="${TYPE[$i]}" 
			LOG_PATH_ON_DISK[${QTY_OF_OS_ON_DISK[$m]}]="${LOG_PATH[$i]}"; MBR_PATH_ON_DISK[${QTY_OF_OS_ON_DISK[$m]}]="${MBR_PATH[$i]}"
		fi
	done
	echo "Total of ${QTY_OF_OS_ON_DISK[$m]} OS detected on ${DISK[$m]} disk."
	#echo "IF A MBR BACKUP ALREADY EXISTS ON THE DISK, IT IS REMOVED IF IT CONTAINS 'GRUB', IF NOT IT IS MEMORIZED IN /tmp."
	for ((k=1;k<=QTY_OF_OS_ON_DISK[m];k++));do ##Loop on Linux OS (backup has less chances to be altered by virus or else)
		if [[ "${TYPE_ON_DISK[$k]}" = "linux" ]] && [[ "$(dir "${MBR_PATH_ON_DISK[$k]}" )" ]];then
			#echo "DETECTS THE PREVIOUS MBR BACKUPS ON LINUX PARTITIONS"
			on_a_given_partition_put_backup_in_tmp_or_remove_it_if_grub
		fi
	done
	for ((k=1;k<=QTY_OF_OS_ON_DISK[m];k++));do ##Second loop on non-Linux OS
		if [[ "${TYPE_ON_DISK[$k]}" != "linux" ]] && [[ "$(dir "${MBR_PATH_ON_DISK[$k]}" )" ]];then
			#echo "DETECTS THE PREVIOUS MBR BACKUPS ON NON-LINUX PARTITIONS"
			on_a_given_partition_put_backup_in_tmp_or_remove_it_if_grub
		fi
	done
	for i in $(dir "$TMP_FOLDER/${DISK[$m]}" ); do
		if [[ "$(grep "mbr-" <<< $i )" ]];then
			(( NB_OF_BACKUPS_IN_DISK[${DISK[$m]}] += 1 ))
			if [[ "${DISKS_WITH_BACKUP[$QTY_OF_DISKS_WITH_BACKUP]}" != "${DISK[$m]}" ]];then
				(( QTY_OF_DISKS_WITH_BACKUP += 1 ))
				DISKS_WITH_BACKUP[$QTY_OF_DISKS_WITH_BACKUP]="${DISK[$m]}"
				#echo "$QTY_OF_DISKS_WITH_BACKUP disks with backup"
			fi
		fi
	done
done
for ((i=1;i<=QTY_OF_DISKS_WITH_BACKUP;i++)); do
	echo "${DISKS_WITH_BACKUP[$i]} contains a backup"
done
}

on_a_given_partition_put_backup_in_tmp_or_remove_it_if_grub()
{
for i in $(dir "${MBR_PATH_ON_DISK[$k]}" ); do
	# First backup system
	if [[ "$(grep "mbr-" <<< $i )" ]] && [[ ! -f "$TMP_FOLDER/${DISK[$m]}/$i" ]];then
		check_if_tmp_mbr_is_grub_type "${MBR_PATH_ON_DISK[$k]}/$i"
		if [[ "$MBRCONTAINSGRUB" = "false" ]]; then 
			mkdir -p "$TMP_FOLDER/${DISK[$m]}"
			cp "${MBR_PATH_ON_DISK[$k]}/$i" "$TMP_FOLDER/${DISK[$m]}"
			echo "************${MBR_PATH_ON_DISK[$k]}/$i has been saved into $TMP_FOLDER/${DISK[$m]}"
		else
			mv "${MBR_PATH_ON_DISK[$k]}/$i" "$TMP_FOLDER/${DISK[$m]}/withgrub.$i.img"
			echo "***** Useless backup on ${OS_PARTITION_ON_DISK[$k]} moved to $TMP_FOLDER/${DISK[$m]}/withgrub.$i.img"
		fi
	fi
	# Second backup system
	if [[ -d "${MBR_PATH_ON_DISK[$k]}/$i" ]];then
		for j in $(dir "${MBR_PATH_ON_DISK[$k]}/$i"); do # Here $i is a folder named by a UUID and containing a backup $j
			if [[ "$(grep "mbr-" <<< $j )" ]];then
				check_if_tmp_mbr_is_grub_type "${MBR_PATH_ON_DISK[$k]}/$i/$j"
				if [[ "$MBRCONTAINSGRUB" = "false" ]]; then
					if [[ ! -f $TMP_FOLDER/UUID/$i/$j ]];then
						mkdir -p "$TMP_FOLDER/UUID/$i/"
						cp "${MBR_PATH_ON_DISK[$k]}/$i/$j" "$TMP_FOLDER/UUID/$i/"
						echo "***To keep the UUID data, ${MBR_PATH_ON_DISK[$k]}/$i/$j has been saved into $TMP_FOLDER/UUID/$i/"
					fi
					for ((l=1;l<=NBOFPARTITIONS;l++)); do
						#echo "2nd backup system : check if $i is the UUID of ${LISTOFPARTITIONS[$l]}"
						if [[ "$i" = "${PART_UUID[$l]}" ]];then  #To get the disk of the partition with $i UUID
							if [[ ! -f $TMP_FOLDER/${DISK_PART[$l]}/$j ]];then
								mkdir -p "$TMP_FOLDER/${DISK_PART[$l]}"
								cp "${MBR_PATH_ON_DISK[$k]}/$i/$j" "$TMP_FOLDER/${DISK_PART[$l]}/"
								# Backup coming from another disk  (for MBR restore)
								echo "******For possible backup restore ${MBR_PATH_ON_DISK[$k]}/$i/$j has been saved into $TMP_FOLDER/${DISK_PART[$l]}/"
							fi
						fi
					done
				else
					mv "${MBR_PATH_ON_DISK[$k]}/$i/$j" "$TMP_FOLDER/${DISK[$m]}/withgrub.$i.img"
					echo "***** Useless backup in ${OS_PARTITION_ON_DISK[$k]}/$i moved to $TMP_FOLDER/${DISK[$m]}/withgrub.$i.img"
				fi
			fi
		done
	fi
done
}

################################ DUPLICATE THE 'first' AND 'last' BACKUPS FROM TMP ##################################################
# called by : before, after, bootrepair, uninstaller
duplicate_backup_from_tmp_to_os_without_backup()
{
#echo "IF SOME OS WITHOUT BACKUP REMAIN, WE DUPLICATE THE BACKUP INTO THEM (INCREASES SAFETY)"
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
	mkdir -p "${MBR_PATH[$i]}"  # In case it has been deleted (by virus or else)
	# First backup system in all OSs of the disk (Clean-Ubiquity v1)
	if [[ "$(dir "$TMP_FOLDER/${OS_DISK[$i]}" | grep -i "mbr-")" ]]; then
		cp $TMP_FOLDER/${OS_DISK[$i]}/mbr-* "${MBR_PATH[$i]}"
		#echo "******v1 Backups duplicated into ${MBR_PATH[$i]}"
	fi
	# Second backup system with UUID in all OSs of all disks (Clean-Ubiquity v2 and next)
	if [[ -d $TMP_FOLDER/UUID/ ]];then
		cp -fr $TMP_FOLDER/UUID/* "${MBR_PATH[$i]}"
		#echo "******v2 Backups (with UUID) duplicated into ${MBR_PATH[$i]}"
	fi
done
}


################################ PUT THE CURRENT MBRs IN TMP ##################################################
# called by : before, after, uninstaller , repair
put_the_current_mbr_in_tmp()
{
#echo "PUT THE CURRENT MBRs IN TMP"
for ((i=1;i<=NBOFDISKS;i++)); do
	if [[ ! -f $TMP_FOLDER/${LISTOFDISKS[$i]}/current_mbr.img ]]; then
		dd if=/dev/${LISTOFDISKS[$i]} of=$TMP_FOLDER/${LISTOFDISKS[$i]}/current_mbr.img bs=${BYTES_BEFORE_PART[$i]} count=1
		# echo "******The current MBR of ${LISTOFDISKS[$i]} have been duplicated into $TMP_FOLDER/${LISTOFDISKS[$i]}/current_mbr.img"
	fi
done
}


############################# CHECKS IF TMP/MBR IS GRUB TYPE OR NOT #############################################
# called by : uninstaller , before
check_if_tmp_mbr_is_grub_type()
{
if [[ -f $1 ]];then
	if [[ "$(dd if=$1 bs=446 count=1 | hexdump -e \"%_p\" | grep -i "GRUB")" ]];then
		MBRCONTAINSGRUB="true"; #echo "the tested MBR contains the word <GRUB>."
	else
		MBRCONTAINSGRUB="false"; #echo "the tested MBR does not contain the word <GRUB>, so stage1 is not installed into this MBR."
	fi
else
	MBRCONTAINSGRUB="error"; echo "Error : $1 does not exist, so we cannot check type."
fi
}

########################################### REMOVE STAGE1 FROM UNWANTED PARTITIONS ##################################################################
remove_stage1_from_other_os_partitions()
{
mount_all_blkid_partitions_except_df
#echo "Remove_stage1_from_other_os_partitions"
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ -d "${BLKIDMNT_POINT[$i]}/Boot" ]] || [[ -d "${BLKIDMNT_POINT[$i]}/BOOT" ]] && [[ -d "${BLKIDMNT_POINT[$i]}/boot" ]];then
		temp=0
		for j in $(dir "${BLKIDMNT_POINT[$i]}"); do #For fat (case insensitive)
			if [[ "$j" = "Boot" ]] || [[ "$j" = "BOOT" ]] || [[ "$j" = "boot" ]];then
				(( temp += 1 ))
			fi
		done
		if [[ "$temp" != "1" ]];then
			echo "$temp /boot folders exist in ${BLKIDMNT_POINT[$i]} and may disturb os-prober, we rename boot into oldbooot"
			mv "${BLKIDMNT_POINT[$i]}/boot" "${BLKIDMNT_POINT[$i]}/oldbooot"
		fi
	fi
done
}
