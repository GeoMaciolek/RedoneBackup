#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## TRANSLATIONS FOR BOOT-REPAIR
## http://ubuntuforums.org/showthread.php?t=1615667


update_translations_br()
{
# Zenity (Boot-Repair)
Boot_sector_successfully_repaired=$(eval_gettext $'Boot successfully repaired.')
You_can_now_reboot=$(eval_gettext $'You can now reboot your computer.')
GRUB_reinstallation_has_been_cancelled=$(eval_gettext $'GRUB reinstallation has been cancelled.')
is_now_without_GRUB=$(eval_gettext $'is now without GRUB.')
#/// TRANSLATORS: Please do not translate ${THISPARTITION}
THISPARTITION_is_nearly_full=$(eval_gettext $'The ${THISPARTITION} partition is nearly full.')
#/// TRANSLATORS: Please do not translate ${THISPARTITION}
THISPARTITION_is_still_full=$(eval_gettext $'The ${THISPARTITION} partition is still full.')
This_can_prevent_to_start_it=$(eval_gettext $'This can prevent to start it')
Power_manager_error=$(eval_gettext $'e.g. you may get a Power Manager error')
Please_use_the_file_browser=$(eval_gettext $'Please use the file browser that just opened to delete unused files (or transfer them to another disk).')
Close_this_window_when_finished=$(eval_gettext $'Close this window when you have finished.')

#glade2script chains (Boot-Repair)
#/// TRANSLATORS: this will appear as the application name
Boot_Repair=$(eval_gettext $'Boot Repair')  #for the .desktop
#/// TRANSLATORS: this is the short description of the application
Repair_the_boot_of_the_computer=$(eval_gettext $'Repair the boot of the computer')  #for the .desktop
Recommended_repair=$(eval_gettext $'Recommended repair')
repairs_most_frequent_problems=$(eval_gettext $'repairs most frequent problems')
#/// TRANSLATORS: Please do not translate BootInfo
Create_a_BootInfo_report=$(eval_gettext $'Create a BootInfo summary')
to_get_help_by_email_or_forum=$(eval_gettext $'to get help by email or forum')
requires_internet=$(eval_gettext $'requires internet')
Repair_file_systems=$(eval_gettext $'Repair file systems')
Please_note_the_following_url=$(eval_gettext $'Please note the following URL:')
Indicate_it_in_case_still_pb=$(eval_gettext $'In case you still experience boot problem, indicate this URL to:')
or_to_your_favorite_support_forum=$(eval_gettext $'or to your favorite support forum.')
Please_open_a_terminal_then_type_the_following_command=$(eval_gettext $'Please open a terminal then type (or copy-paste) the following command:')
Then_choose_Yes_when_the_below_window_appears=$(eval_gettext $'Then when a window similar to the one below appear in your terminal, use Tab and Enter keys in order to confirm GRUB removal.')
Now_please_type_this_command_in_the_terminal=$(eval_gettext $'Now please type (or copy-paste) the following command in a terminal:')
Then_select_correct_device_when_the_below_window_appears=$(eval_gettext $'Then when menus similar to the one below appear in your terminal, use Tab, Space and Enter keys in order to install GRUB in the disk you wish.')
GRUB_is_still_present=$(eval_gettext $'GRUB is still present.')
GRUB_is_still_absent=$(eval_gettext $'GRUB is still absent.')
Please_try_again=$(eval_gettext $'Please try again.')
}

