#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## 17/12/2011
## Special thanks to Babdu89, Josepe36, Meierfra & Gert Hulselmans. 

## ACTION LIBRAIRIES SPECIFIC TO BOOT-REPAIR
## LIBRAIRIES D'ACTIONS SPECIFIQUES AU REPARATEUR D'AMORCAGE

########################## REPAIR SEQUENCE DEPENDING ON USER CHOICE ##########################################
bootrepairactions()
{
echo "************************Before Repairing"; debug_echo_important_variables
if [[ "$FSCK_ACTION" = "yes" ]];then
	fsck_function					#Unmount all OS partition then remounts them
fi
if [[ "$MBR_ACTION" != "nombraction" ]];then
	freed_space_function				#Requires Linux partitions to be mounted
fi
if [[ "$MBR_ACTION" = "purge" ]];then
	check_internet_connection
	if [[ "$INTERNET" = "no connection" ]];then
		end_of_pulsate
		zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="$No_internet_connection_detected"
		echo 'SET@_mainwindow.show()'
	else
		purge_grub
	fi
else
	if [[ "$UNHIDEBOOT_ACTION" = "yes" ]];then	#Requires all OS partitions to be mounted
		unhide_boot_menus_etc_default_grub
	fi
	if [[ "$MBR_ACTION" = "reinstall" ]];then
		reinstall_action
	elif [[ "$MBR_ACTION" = "restore" ]]; then
		restore_mbr
	fi
	unmount_all_and_success_repair
fi
}

########################## UNMOUNT ALL AND SUCCESS REPAIR ##########################################
unmount_all_and_success_repair()
{
if [[ "$UNHIDEBOOT_ACTION" = "yes" ]];then
	unhide_boot_menus_xp
	unhide_boot_menus_grubcfg	#To remplace the "-1"
fi
if [[ "$INTERNET" = "connected" ]];then
	pastebinaction
fi
save_log_on_disks
unmount_all_blkid_partitions_except_df
end_of_pulsate
if [[ "$PASTEBIN_ACTION" = "yes" ]] && [[ ! "$PASTEBIN_URL" ]];then
	zenity --error --text="Could not create BootInfo summary. ${please_install_PACKAGELIST} ${Then_try_again}"
else
	if [[ "$PASTEBIN_URL" ]];then
		FINALTEXT="${Please_note_the_following_url}\\n   $PASTEBIN_URL\\n   ${Indicate_it_in_case_still_pb}\\n   boot.repair@gmail.com \\n${or_to_your_favorite_support_forum}\\n"
	fi
	if [[ "$MBR_ACTION" != "nombraction" ]] || [[ "$UNHIDEBOOT_ACTION" = "yes" ]] || [[ "$FSCK_ACTION" = "yes" ]];then
		FINALTEXT="${Boot_sector_successfully_repaired}\\n${FINALTEXT}${You_can_now_reboot}"
	fi
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${FINALTEXT}"
fi
echo "End of unmount_all_and_success_repair"
echo 'EXIT@@'
}

########################## PASTEBIN ACTION ##########################################
pastebinaction()
{
check_internet_connection
if [[ "$INTERNET" = "connected" ]];then
	if [[ "$SENDSTATS" != "nostats" ]];then
		statsbr
	fi
	if [[ ! -f /usr/bin/pastebinit ]] || [[ ! -f /usr/bin/gawk ]] && [[ "$PASTEBIN_ACTION" = "yes" ]];then
		echo "SET@_label0.set_text('''$Create_a_BootInfo_report. $(eval_gettext $'This may require several minutes...')''')"
		if [[ ! -f /usr/bin/pastebinit ]] && [[ ! -f /usr/bin/gawk ]];then
			PACKAGELIST="pastebinit gawk"
		elif [[ ! -f /usr/bin/pastebinit ]];then
			PACKAGELIST="pastebinit"
		else
			PACKAGELIST="gawk"
		fi
		update_translations
		end_of_pulsate
		zenity --question --title="$(eval_gettext "$CLEANNAME")" --text="${This_will_install_PACKAGELIST} ${Do_you_want_to_continue}" || bisenable="no"
		beginning_of_pulsate
		if [[ "$bisenable" != "no" ]];then
			loop_pastebinaction
			if [[ ! -f /usr/bin/pastebinit ]] || [[ ! -f /usr/bin/gawk ]];then
				activate_all_repositories	#Pastebinit requires Universe on Ubuntu
				loop_pastebinaction
				restore_original_repositories
				if [[ ! -f /usr/bin/pastebinit ]] || [[ ! -f /usr/bin/gawk ]];then
					end_of_pulsate
					zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${please_install_PACKAGELIST} ${Then_try_again}"
					beginning_of_pulsate
				fi
			fi
		fi
	fi
	if [[ -f /usr/bin/pastebinit ]] && [[ -f /usr/bin/gawk ]];then
		echo "SET@_label0.set_text('''$Create_a_BootInfo_report. $(eval_gettext $'Please wait few seconds...')''')"
		cp $TMP_LOG.tee $TMP_LOG.pastetmp
		while read line; do
			if [[ ! "$(grep "becomes" <<< $line )" ]] && [[ ! "$(grep "SET@" <<< $line )" ]] && [[ ! "$(grep "DEBUG=>" <<< $line )" ]] && [[ ! "$(grep "1+0 records" <<< $line )" ]] && [[ ! "$(grep ") copied, " <<< $line )" ]] && [[ ! "$(grep "gpg: " <<< $line )" ]] && [[ ! "$(grep "Executing: gpg " <<< $line )" ]] && [[ ! "$(grep "1+0 " <<< $line )" ]] && [[ ! "$(grep "B\/s" <<< $line )" ]] && [[ ! "$(grep "COMBO@@" <<< $line )" ]];then
				echo "$line" >> $TMP_LOG.paste
			fi
		done < <(echo "$(< $TMP_LOG.pastetmp)")
		rm $TMP_LOG.pastetmp
	fi
fi
check_internet_connection
if [[ "$INTERNET" = "connected" ]] && [[ -f /usr/bin/pastebinit ]] && [[ -f /usr/bin/gawk ]];then
	unmount_all_blkid_partitions_except_df # necessary ?
	#courtesy of forum members Meierfra & Gert Hulselmans
	cp /usr/share/clean/boot_info_script.sh ${TMP_FOLDER}/boot_info_script.sh
	LC_MESSAGES=C bash ${TMP_FOLDER}/boot_info_script.sh
	rm ${TMP_FOLDER}/boot_info_script.sh
	echo "ADDITIONAL INFORMATION :" >> ${TMP_FOLDER}/RESULTS.txt
	cat $TMP_LOG.paste >> ${TMP_FOLDER}/RESULTS.txt
	if [[ "$(lsb_release -is)" != "Ubuntu" ]];then
		PASTEBIN_URL=$(cat ${TMP_FOLDER}/RESULTS.txt | pastebinit -a boot-repair -f bash -b http://paste.debian.net)
	fi
	if [[ "$(lsb_release -is)" = "Ubuntu" ]] || [[ "$PASTEBIN_URL" = "http://paste.debian.net/" ]];then #workaround for debianpaste bug
		PASTEBIN_URL=$(cat ${TMP_FOLDER}/RESULTS.txt | pastebinit -a boot-repair -f bash -b http://paste.ubuntu.com)
	fi
fi
mount_all_blkid_partitions_except_df #For logs
}

loop_pastebinaction()
{
temp="$(apt-get -y update)"
temp2="$(apt-get install -y --force-yes pastebinit gawk)"
if [[ ! "$temp" ]] || [[ ! "$temp2" ]];then
	end_of_pulsate
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="${Please_close_all_your_package_managers} (${Software_Centre}, ${Update_Manager}, Synaptic, ...)."
	beginning_of_pulsate
fi
}


########################################### REPAIR PARTITIONS (FSCK) ##################################################################
fsck_function()
{
force_unmount_blkid_partitions
#fsck -fyM  # repair partitions detected in the /etc/fstab except those mounted
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	echo "SET@_label0.set_text('''$Repair_file_systems ${LISTOFPARTITIONS[$i]}. $(eval_gettext $'This may require several minutes...')''')"
	temp="$(fdisk -l | grep "/dev/${LISTOFPARTITIONS[$i]} " )"
	if [[ "$(grep -i "NTFS" <<< "$temp" )" ]];then
		ntfsfix /dev/${LISTOFPARTITIONS[$i]}	#Repair NTFS partitions
	else
		fsck -fyM /dev/${LISTOFPARTITIONS[$i]}	#Repair other partitions
	fi
done
mount_all_blkid_partitions_except_df
}

#Called by fsck_function
force_unmount_blkid_partitions()
{
end_of_pulsate
zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="Filesystem repair requires to unmount partitions. Please close all your programs, then close this window to continue."
beginning_of_pulsate
echo "Force Unmount all blkid partitions (for fsck) except / /boot /cdrom /dev /etc /home /opt /pas /proc /rofs /sys /tmp /usr /var "
pkill pcmanfm	#To avoid it automounts
for ((i=1;i<=NBOFPARTITIONS;i++)); do
	if [[ "${BLKIDMNT_POINT[$i]}" ]] && [[ ! $(grep "/boot" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ "${BLKIDMNT_POINT[$i]}" != "/cdrom" ]] && [[ ! $(grep "/dev" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/etc" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ "${BLKIDMNT_POINT[$i]}" != "/home" ]] && [[ ! $(grep "/opt" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/pas" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/proc" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/rofs" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/sys" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/tmp" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/usr" <<< "${BLKIDMNT_POINT[$i]}" ) ]] && [[ ! $(grep "/var" <<< "${BLKIDMNT_POINT[$i]}" ) ]];then
		umount "${BLKIDMNT_POINT[$i]}"
	fi
done
}

########################################### FREED SPACE ACTION ##################################################################
freed_space_function()
{
#Workaround for this bug: https://bugs.launchpad.net/bugs/610358
echo "Freed space function"
echo "SET@_label0.set_text('''Checking full partitions. $(eval_gettext $'This may require several minutes...')''')"
#for ((i=1;i<=QTY_OF_PART_WITH_APTGET;i++)); do 
#	if [[ "${OS_PARTITION[${LIST_OF_PART_WITH_APTGET[$i]}]}" = "$CURRENTSESSIONPARTITION" ]];then
#		apt-get -y clean
#		apt-get -y autoremove
#	else
#		for w in dev dev/pts proc sys; do
#			mount -B /$w "${MNT_PATH[${LIST_OF_PART_WITH_APTGET[$i]}]}/$w"
#		done  # /dev/pts ???
#		chroot "${MNT_PATH[${LIST_OF_PART_WITH_APTGET[$i]}]}" apt-get -y clean
#		chroot "${MNT_PATH[${LIST_OF_PART_WITH_APTGET[$i]}]}" apt-get -y autoremove
#		pkill pcmanfm	#To avoid it automounts
#		for w in dev/pts dev proc sys; do
#			umount "${MNT_PATH[${LIST_OF_PART_WITH_APTGET[$i]}]}/$w"
#		done
#	fi
#done
# Warn if still full partition
for ((i=1;i<=TOTAL_QUANTITY_OF_OS;i++)); do
	echo "$(df /dev/${OS_PARTITION[$i]} | grep "/dev/" )"
	USEDPERCENT=$(df /dev/${OS_PARTITION[$i]} | grep "/dev/" ); USEDPERCENT=${USEDPERCENT%%\%*}; USEDPERCENT=${USEDPERCENT##* }
	#echo "$USEDPERCENT"
	if [[ "$USEDPERCENT" -ge "95" ]];then
		end_of_pulsate
		if [[ -d "${MNT_PATH[$i]}/home" ]];then
			xdg-open "${MNT_PATH[$i]}/home" &
		elif [[ -d "${MNT_PATH[$i]}/Documents and Settings" ]];then
			xdg-open "${MNT_PATH[$i]}/Documents and Settings" &
		elif [[ "${OS_PARTITION[$i]}" = "$CURRENTSESSIONPARTITION" ]];then
			xdg-open "/" &
		elif [[ "$(grep "/mnt/$PACK_NAME" <<< "${MNT_PATH[$i]}" )" ]];then #To avoid https://bugs.launchpad.net/ubuntu/+source/xdg-utils/+bug/821284
			xdg-open "/mnt/$PACK_NAME" &
		else
			xdg-open "/" &
		fi
		THISPARTITION="${OS_PARTITION[$i]} \(${OS_NAME[$i]}\)" #TODO: integrate variables into mo for arabic translation
		update_translations
		zenity --warning --title="$(eval_gettext "$CLEANNAME")" --text="${THISPARTITION_is_nearly_full} ${This_can_prevent_to_start_it}. $Please_use_the_file_browser $Close_this_window_when_finished"
		USEDPERCENT=$(df /dev/${OS_PARTITION[$i]} | grep "/dev/" ); USEDPERCENT=${USEDPERCENT%%\%*}; USEDPERCENT=${USEDPERCENT##* }
		if [[ "$USEDPERCENT" -ge "97" ]];then
			zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="${THISPARTITION_is_still_full} ${This_can_prevent_to_start_it} (${Power_manager_error})."
		fi
		beginning_of_pulsate
	fi
done
}


######################### STATS FOR IMPROVING BOOT-REPAIR##################
statsbr()
{
stats
wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/bi http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.$MAIN_MENU.counter/download
if [[ "$MAIN_MENU" != "bootinfo" ]];then
	wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/re http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.repair.counter/download
	wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/bi http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.$MBR_ACTION.counter/download
	if [[ "$FSCK_ACTION" = "yes" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/fsck http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.fsck.counter/download
	fi
	if [[ "$UNHIDEBOOT_ACTION" = "yes" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/uh http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.unhide.counter/download
	fi
	if [[ "$UNCOMMENT_GFXMODE" = "yes" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/gf http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.gfx.counter/download
	fi
	if [[ "$ADD_KERNEL_OPTION" = "yes" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/ke http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.kernel.counter/download
	fi
	if [[ "$ATA" = "ata" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/at http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.ata.counter/download
	fi
	if [[ "$REMOVABLEDISK" = "yes" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/gf http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.removabledisk.counter/download
	fi
	if [[ "$GRUBPACKAGE" = "grub-efi" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/efi http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.efi.counter/download
	fi
	if [[ "$(grep "Ubuntu" <<< $(lsb_release -d -s) )" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/ub http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.ubuntu.counter/download
	elif [[ "$(grep "Debian" <<< $(lsb_release -d -s) )" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/de http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.debian.counter/download
	elif [[ "$(grep "Mint" <<< $(lsb_release -d -s) )" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/gf http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.gfx.counter/download
	elif [[ "$(grep "Hybryde" <<< $(lsb_release -d -s) )" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/hy http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.hybryde.counter/download
	else
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/oh http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.otherhost.counter/download
	fi
	if [[ "$QUANTITY_OF_DETECTED_LINUX" != "0" ]] && [[ "$QUANTITY_OF_DETECTED_WINDOWS" = "0" ]] && [[ "$QUANTITY_OF_DETECTED_MACOS" = "0" ]] && [[ "$QUANTITY_OF_UNKNOWN_OS" = "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/lo http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.linuxonly.counter/download
	elif [[ "$QUANTITY_OF_DETECTED_LINUX" = "0" ]] && [[ "$QUANTITY_OF_DETECTED_WINDOWS" != "0" ]] && [[ "$QUANTITY_OF_DETECTED_MACOS" = "0" ]] && [[ "$QUANTITY_OF_UNKNOWN_OS" = "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/wo http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.winonly.counter/download
	elif [[ "$QUANTITY_OF_DETECTED_LINUX" = "0" ]] && [[ "$QUANTITY_OF_DETECTED_WINDOWS" = "0" ]] && [[ "$QUANTITY_OF_DETECTED_MACOS" != "0" ]] && [[ "$QUANTITY_OF_UNKNOWN_OS" = "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/mo http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.maconly.counter/download
	fi
	if [[ "$QUANTITY_OF_UNKNOWN_OS" != "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/uo http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.unknownos.counter/download
	fi
	if [[ "$TOTAL_QUANTITY_OF_OS" = "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/0o http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.0os.counter/download
	elif [[ "$TOTAL_QUANTITY_OF_OS" = "1" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/1o http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.1os.counter/download
	elif [[ "$TOTAL_QUANTITY_OF_OS" = "2" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/2o http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.2os.counter/download
	else
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/3o http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.3osormore.counter/download
	fi
	if [[ "$(grep "LVM2_member" <<< $BLKID )" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/lv http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.lvm.counter/download
	fi
	if [[ "$DMRAID" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/dm http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.dmraid.counter/download
	fi
	if [[ "$QTY_OF_DISKS_WITH_BACKUP" != "0" ]];then
		wget -o /dev/null -O ${TMP_FOLDER_TO_BE_CLEARED}/cu http://sourceforge.net/projects/boot-repair/files/statistics/boot-repair.cleanubiquity.counter/download
	fi
fi
}
