#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## Special thanks to Babdu89, Josepe36, and GRUB devs. 

## BOOT-REPAIR
## Allows to repair the GRUB or restore the initial boot sector of any Linux distribution previously installed via the "Clean-Ubiquity" script.
## http://ubuntuforums.org/showthread.php?t=1615667

## REPARATEUR D'AMORCAGE
## Permet de réparer le GRUB ou restaurer l'amorcage initial de n'importe-quelle distribution Linux ayant été installée via le script "Clean-Ubiquity".
## http://forum.ubuntu-fr.org/viewtopic.php?pid=3786646


PID=$$; FIFO=/tmp/FIFO${PID}; mkfifo ${FIFO}		# Initialization of the Glade2script interface
APPNAME="boot-repair"
CLEANNAME="Boot Repair"
. /usr/share/clean/cleancommon-gui.sh			#GUI librairies common to os-uninstaller and boot-repair
######## Preparation of pulsate #########
translations_init
echo "SET@pulsatewindow.set_icon_from_file('''$APPNAME.png''')"
echo "SET@pulsatewindow.set_title('''$(eval_gettext "$CLEANNAME")''')"
echo "SET@_label0.set_text('''$(eval_gettext $'Scanning systems'). $(eval_gettext $'This may require several minutes...')''')"
beginning_of_pulsate
######## During pulsate ########
. /usr/share/clean/boot-repair-translations.sh		#boot-repair translations
. /usr/share/clean/cleancommon.sh			#Librairies common to os-uninstaller, boot-repair, and clean-ubiquity
. /usr/share/clean/cleancommon-actions.sh		#Action librairies common to os-uninstaller and boot-repair
. /usr/share/clean/bootrepair-actions.sh		#Action librairies specific to boot-repair
. /usr/share/clean/bootrepair-gui.sh			#GUI librairies specific to boot-repair
init_and_updateapp
if [[ "$choice" != "exit" ]];then
	check_os_and_mount_blkid_partitions_gui
	check_which_mbr_can_be_restored
	save_log_on_disks
	mainwindow_filling
	end_of_pulsate
	check_64bits_and_show_mainwindow
fi
loop_of_the_glade2script_interface
