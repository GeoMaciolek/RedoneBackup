#! /bin/bash
############################################################################
##                                                                        ##
##     Copyright (C) 2010-2011  YannUbuntu (yannubuntu@gmail.com)         ##
##                                                                        ##
## This program is free software: you can redistribute it and/or modify   ##
## it under the terms of the GNU General Public License as published by   ##
## the Free Software Foundation, either version 3 of the License, or      ##
## (at your option) any later version.                                    ##
##                                                                        ##
## This program is distributed in the hope that it will be useful,        ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of         ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          ##
## GNU General Public License for more details.                           ##
##                                                                        ##
## You should have received a copy of the GNU General Public License      ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>.  ##
##                                                                        ##
############################################################################
## 09/12/2011
## Special thanks to Babdu, Hizoka, and Ansuz. 

## GUI LIBRAIRIES SPECIFIC TO BOOT-REPAIR
## LIBRAIRIES GUI SPECIFIQUES AU REPARATEUR D'AMORCAGE


########################## mainwindow filling ##########################################
# inputs : all
# outputs : mainwindow window
mainwindow_filling()
{
echo 'SET@_vbox_bootrepairmenu.show()'
echo "SET@_label_bootrepairsubtitle.set_markup('''<b>${Repair_the_boot_of_the_computer}</b>''')"
echo "SET@_label_recommendedrepair.set_text('''${Recommended_repair}\\n(${repairs_most_frequent_problems})''')"
echo "SET@_label_justbootinfo.set_text('''${Create_a_BootInfo_report}\\n(${to_get_help_by_email_or_forum})''')"
echo "SET@_label_repairfilesystems.set_text('''${Repair_file_systems}''')"
echo "SET@_label_pastebin.set_text('''${Create_a_BootInfo_report} (${to_get_help_by_email_or_forum})''')"
echo 'SET@_button_mainapply.hide()'
echo "SET@_label_purge_grub.set_text('''${Purge_and_reinstall_the_grub_of}''')"
echo "SET@_label_appname.set_markup('''<b><big>Boot-Repair</big></b>''')" # ${APPNAME_VERSION%~*}
echo "SET@_label_appdescription.set_text('''${Repair_the_boot_of_the_computer}''')"
echo 'SET@_logobr.show()'
echo "SET@_linkbutton_websitebr.show()"

if [[ "$QTY_OF_PART_WITH_APTGET" != "0" ]];then ####### Combo_purge_grub fillin (Purge GRUB)
	QTY_OF_PART_FOR_PURGE=0
	if [[ "$(uname -m)" != "x86_64" ]];then
		loop_purge_grub_fillin 64
		loop_purge_grub_fillin 32
	else
		loop_purge_grub_fillin noorder
	fi
	for ((i=1;i<=QTY_OF_PART_FOR_PURGE;i++)); do
		LABEL_PART_FOR_PURGE[$i]="${LISTOFPARTITIONS[${LIST_OF_PART_FOR_PURGE[$i]}]}"
		for ((j=1;j<=TOTAL_QUANTITY_OF_OS;j++)); do  
			if [[ "${OS_PARTITION[$j]}" = "${LISTOFPARTITIONS[${LIST_OF_PART_FOR_PURGE[$i]}]}" ]]; then
				LABEL_PART_FOR_PURGE[$i]="${OS_PARTITION[$j]} \(${OS_NAME[$j]}\)"
			fi
		done
		#echo "LABEL_PART_FOR_PURGE[$i] ${LABEL_PART_FOR_PURGE[$i]}" #debug
	done
	while read fichier; do echo "SET@_combobox_purge_grub.append_text('''${fichier}''')";done < <( for ((i=1;i<=QTY_OF_PART_FOR_PURGE;i++)); do
		echo "${LABEL_PART_FOR_PURGE[$i]}"
	done)
fi
if [[ "$PURGE_POSSIBLE" = "yes" ]];then
	echo 'SET@_hbox_purge_grub.set_sensitive(True)'
	echo 'SET@_combobox_purge_grub.set_active(0)'
	PART_TO_REINSTALL_GRUB_PURGE="${LIST_OF_PART_FOR_PURGE[1]}"
else
	echo 'SET@_hbox_purge_grub.set_sensitive(False)'
fi

common_labels_fillin
set_easy_repair
echo "************************Before mainwindow appear"; debug_echo_important_variables
}


_button_recommendedrepair()
{
_button_mainapply
}

set_easy_repair()
{
echo 'SET@_button_recommendedrepair.set_sensitive(False)' #To avoid applying before variables are changed
MAIN_MENU="recommendedrepair"; echo "MAIN_MENU becomes : $MAIN_MENU"
UNHIDEBOOT_ACTION="yes"; echo 'SET@_checkbutton_unhide_boot_menu.set_active(True)'
FSCK_ACTION="no"; echo 'SET@_checkbutton_repairfilesystems.set_active(False)'
if [[ "$INTERNET" = "connected" ]];then
	PASTEBIN_ACTION="yes"; echo 'SET@_checkbutton_pastebin.set_active(True)'
else
	PASTEBIN_ACTION="no"; echo 'SET@_checkbutton_pastebin.set_active(False)'
fi
if [[ "$REINSTALL_POSSIBLE" = "yes" ]] || [[ "$PURGE_POSSIBLE" = "yes" ]];then
	set_checkbutton_reinstall_grub
	echo 'SET@_checkbutton_reinstall_grub.set_active(True)'
else
	echo 'SET@_checkbutton_reinstall_grub.hide()'
	set_checkbutton_restore_mbr
	echo 'SET@_checkbutton_restore_mbr.set_active(True)'
fi
echo 'SET@_button_recommendedrepair.set_sensitive(True)'
}

_button_justbootinfo()
{
MAIN_MENU="bootinfo"; echo "MAIN_MENU becomes : $MAIN_MENU"
_button_mainapply
}

_checkbutton_repairfilesystems()
{
RETOURREPAIFILES=${@}
if [[ ${RETOURREPAIFILES} = True ]]; then FSCK_ACTION="yes"; else FSCK_ACTION="no";fi
echo "FSCK_ACTION becomes : $FSCK_ACTION"
}


_checkbutton_pastebin()
{
RETOURPASTEBI=${@}
if [[ ${RETOURPASTEBI} = True ]]; then
	echo 'SET@_button_mainapply.set_sensitive(False)' #To avoid applying before variables are changed
	if [[ "$INTERNET" != "connected" ]];then
		check_internet_connection
	fi
	if [[ "$INTERNET" = "connected" ]];then
		PASTEBIN_ACTION="yes"; echo "PASTEBIN_ACTION becomes : yes"
	else
		echo "SET@_label_pastebin.set_text('''${No_internet_connection_detected}''')"
		sleep 1
		echo 'SET@_checkbutton_pastebin.set_active(False)'
		echo "SET@_label_pastebin.set_text('''${Create_a_BootInfo_report} (${to_get_help_by_email_or_forum})''')"
	fi
	echo 'SET@_button_mainapply.set_sensitive(True)'
else
	PASTEBIN_ACTION="no"; echo "PASTEBIN_ACTION becomes : no"
fi
}



_button_mainapply()
{
echo 'SET@_mainwindow.hide()'
check_internet_connection
if [[ "$MBR_ACTION" = "reinstall" ]] && [[ "${ARCH_OF_PART[$PART_TO_REINSTALL_GRUB]}" != "32" ]] && [[ "$(uname -m)" != "x86_64" ]];then
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session"; unmount_all_partitions_and_quit_glade
elif [[ "$MBR_ACTION" = "purge" ]] && [[ "${ARCH_OF_PART[$PART_TO_REINSTALL_GRUB_PURGE]}" != "32" ]] && [[ "$(uname -m)" != "x86_64" ]];then
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_a_64bits_session"; unmount_all_partitions_and_quit_glade
elif [[ "$LIVESESSION" != "yes" ]] && [[ "$MBR_ACTION" = "reinstall" ]] && [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB]}" != "$CURRENTSESSIONPARTITION" ]];then
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session"; unmount_all_partitions_and_quit_glade
elif [[ "$LIVESESSION" != "yes" ]] && [[ "$MBR_ACTION" = "purge" ]] && [[ "${LISTOFPARTITIONS[$PART_TO_REINSTALL_GRUB_PURGE]}" != "$CURRENTSESSIONPARTITION" ]];then
	zenity --info --title="$(eval_gettext "$CLEANNAME")" --text="$Please_use_in_live_session"; unmount_all_partitions_and_quit_glade
elif [[ "$MBR_ACTION" = "purge" ]] || [[ "$PASTEBIN_ACTION" = "yes" ]] || [[ "$MAIN_MENU" = "bootinfo" ]] && [[ "$INTERNET" = "no connection" ]];then
	zenity --error --title="$(eval_gettext "$CLEANNAME")" --text="${No_internet_connection_detected}. $Please_connect_internet $Then_try_again"
	echo 'SET@_mainwindow.show()'
else
	echo "SET@pulsatewindow.set_title('''${Boot_Repair}''')"
	echo "SET@_label0.set_text('''${Applying_changes} ${This_may_require_several_minutes}''')"
	beginning_of_pulsate
	if [[ "$MAIN_MENU" = "bootinfo" ]];then
		MBR_ACTION="nombraction"
		PASTEBIN_ACTION="yes"
		FSCK_ACTION="no"
		UNHIDEBOOT_ACTION="no"
	fi
	bootrepairactions
fi
}

