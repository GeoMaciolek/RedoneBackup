#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#  ADesk Bar - Quick application launcher
#
#  by ADcomp <david.madbox@gmail.com>
#  http://www.ad-comp.be/
#
#  This program is distributed under the terms of the GNU General Public License
#  For more info see http://www.gnu.org/licenses/gpl.txt
##

import os
import sys
import gtk

try:
    GIO = True
    import gio
except:
    GIO = False

def gtkrc_changed (monitor, file, data, event):
    #~ print event
    global BAR_MGR
    BAR_MGR.resize_and_seticon()

if GIO:
    home = os.environ['HOME']
    file = gio.File( home + '/.gtkrc-2.0')
    monitor = file.monitor_file()
    monitor.connect ("changed", gtkrc_changed)
    
realpath = os.path.dirname(os.path.realpath( __file__ ))
os.chdir(realpath)

if len(sys.argv) == 1:
    cfg_file = 'default'
elif len(sys.argv) == 2:
    cfg_file = sys.argv[1]
else:
    cfg_file = '-h'
    
if cfg_file == '--help' or cfg_file == '-h':
    import adesk.release as release

    print('ADeskBar v%s.%s' % (release.VERSION, release.RC))
    print 
    print('Usage : adeskbar [config_name]')
    print
else:
    import adesk.bar
    global BAR_MGR
    BAR_MGR = adesk.bar.BarManager(cfg_file)
    BAR_MGR.run()
    
